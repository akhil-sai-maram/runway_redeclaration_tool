package java.utils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import utils.*;
import org.junit.jupiter.api.Test;

class NewRunwayInputTests {
    /**
     * Tests that a valid runway input works correctly
     */
    @Test
    void newRunwayTest() {
        RunwayDeclaration runwayDec = new RunwayDeclaration(3886, 3886, 3886, 3964, 27, "R");
        runwayDec.setVars(runwayDec);
        assertEquals(3886, runwayDec.getLDA()); //LDA check
        assertEquals(3886, runwayDec.getTORA()); //TORA check
        assertEquals(3886, runwayDec.getASDA()); //ASDA check
        assertEquals(3964, runwayDec.getTODA()); //TODA check
        assertEquals(27, runwayDec.getHeading()); //heading check
        assertEquals("R", runwayDec.getHeadingExtension()); //heading extension check
    }

}
