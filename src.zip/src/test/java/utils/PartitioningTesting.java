package java.utils;


import exceptions.FormatException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import utils.*;
import exceptions.*;

import static org.junit.jupiter.api.Assertions.*;

public class PartitioningTesting {


    /**
     * This test tests that a valid input works correctly
     */
    @Test
    public void headingBoundaryTest() {
        RunwayDeclaration runwayDec = new RunwayDeclaration(3886, 3886, 3886, 3964, 36, "R");
        runwayDec.setVars(runwayDec);
        assertEquals(3886, runwayDec.getLDA()); //LDA check
        assertEquals(3886, runwayDec.getTORA()); //TORA check
        assertEquals(3886, runwayDec.getASDA()); //ASDA check
        assertEquals(3964, runwayDec.getTODA()); //TODA check
        assertEquals(36, runwayDec.getHeading()); //heading check
        assertEquals("R", runwayDec.getHeadingExtension()); //heading extension check
    }


    /**
     * This tests that an invalid heading on the boundary (37) should throw an exception
     */
    @Test
    public void invalidBoundaryHeadingTest() throws FormatException {
        RunwayDeclaration runwayDec = new RunwayDeclaration(3886, 3886, 3886, 3964, 37, "R");
        runwayDec.setVars(runwayDec);
        HeadingException thrown = Assertions.assertThrows(HeadingException.class, () -> {
            Sanitisation.sanitiseDeclaration(runwayDec);
        });
//        assertEquals(3886, runwayDec.getLDA()); //LDA check
//        assertEquals(3886, runwayDec.getTORA()); //TORA check
//        assertEquals(3886, runwayDec.getASDA()); //ASDA check
//        assertEquals(3964, runwayDec.getTODA()); //TODA check
//        assertEquals(37, runwayDec.getHeading()); //heading check
//        assertEquals("R", runwayDec.getHeadingExtension()); //heading extension check
    }

}
