package java.utils;


import exceptions.FormatException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import utils.ObstacleDeclaration;
import utils.*;
import exceptions.*;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class InvalidObstacleTest {

    /**
     * tests that an invalid height throws an error message
     */
    @Test
    public void testInvalidHeight() {
        RunwayDeclaration runwayDeclaration = new RunwayDeclaration(3884, 3884, 3884, 3962, 27, "R");
        ObstacleDeclaration obstacleDeclaration = new ObstacleDeclaration(500, 3385, 0, 400,27);
        RunwayUtils.landingOver(runwayDeclaration, obstacleDeclaration);
        HeightException thrown = Assertions.assertThrows(HeightException.class, () -> {
            Sanitisation.sanitiseObstacle(runwayDeclaration,obstacleDeclaration,0);
        });
    }

    /**
     * tests that an invalid TORA throws an error message
     */
    @Test
    public void testInvalidTORA() {
        RunwayDeclaration runwayDeclaration = new RunwayDeclaration(3884, 38840000, 3884, 3962, 27, "R");
        ObstacleDeclaration obstacleDeclaration = new ObstacleDeclaration(500, 3385, 0, 25,27);
        RunwayUtils.landingOver(runwayDeclaration, obstacleDeclaration);
        TORAException thrown = Assertions.assertThrows(TORAException.class, () -> {
            Sanitisation.sanitiseObstacle(runwayDeclaration,obstacleDeclaration,0);
        });
    }

    /**
     * tests that an invalid TODA throws an error message
     */
    @Test
    public void testInvalidTODA() {
        RunwayDeclaration runwayDeclaration = new RunwayDeclaration(3884, 3884, 3884, 39629999, 27, "R");
        ObstacleDeclaration obstacleDeclaration = new ObstacleDeclaration(500, 3385, 0, 25,27);
        RunwayUtils.landingOver(runwayDeclaration, obstacleDeclaration);
        TODAException thrown = Assertions.assertThrows(TODAException.class, () -> {
            Sanitisation.sanitiseObstacle(runwayDeclaration,obstacleDeclaration,0);
        });
    }

    /**
     * tests that an invalid height ASDA an error message
     */
    @Test
    public void testInvalidASDA(){
        RunwayDeclaration runwayDeclaration = new RunwayDeclaration(3884, 3884, 388490909, 3962, 27, "R");
        ObstacleDeclaration obstacleDeclaration = new ObstacleDeclaration(500, 3385, 0, 25,27);
        RunwayUtils.landingOver(runwayDeclaration, obstacleDeclaration);
        ASDAException thrown = Assertions.assertThrows(ASDAException.class, () -> {
            Sanitisation.sanitiseObstacle(runwayDeclaration,obstacleDeclaration,0);
        });
    }

}
