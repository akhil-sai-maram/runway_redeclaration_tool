package java.utils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import utils.*;
import org.junit.jupiter.api.Test;

public class RunwayUtilsTest {
  /**
   * Tests that a valid input for landing over an obstacle is accepted
   */
  @Test
  void landingOver() {
    RunwayDeclaration runwayDeclaration = new RunwayDeclaration(3884, 3884, 3884, 3962, 27, "R");
    ObstacleDeclaration obstacleDeclaration = new ObstacleDeclaration(500, 3385, 0, 25,27);
    RunwayUtils.landingOver(runwayDeclaration, obstacleDeclaration);
    assertEquals(2074, runwayDeclaration.getLDA()); //LDA check
    assertEquals(3884, runwayDeclaration.getTORA()); //TORA check
    assertEquals(3884, runwayDeclaration.getASDA()); //ASDA check
    assertEquals(3962, runwayDeclaration.getTODA()); //TODA check
  }

  /**
   * Tests that a valid input for landing towards an obstacle is accepted
   */
  @Test
  void landingToward() {
    RunwayDeclaration runwayDeclaration = new RunwayDeclaration(3595, 3902, 3902, 3902, 9, "L");
    ObstacleDeclaration obstacleDeclaration = new ObstacleDeclaration(2600, 0, 0, 25, 9);
    RunwayUtils.landingToward(runwayDeclaration, obstacleDeclaration);
    assertEquals(2300, runwayDeclaration.getLDA()); //LDA check
    assertEquals(3902, runwayDeclaration.getTORA()); //TORA check
    assertEquals(3902, runwayDeclaration.getASDA()); //ASDA check
    assertEquals(3902, runwayDeclaration.getTODA()); //TODA check
  }

  /**
   * Tests that a valid input for taking off over an obstacle is accepted
   */
  @Test
  void takeoffOver() {
    RunwayDeclaration runwayDeclaration = new RunwayDeclaration(3595, 3902, 3902, 3902, 9, "L");
    ObstacleDeclaration obstacleDeclaration = new ObstacleDeclaration(2806, 0, 0, 25, 9);
    RunwayUtils.takeoffOver(runwayDeclaration, obstacleDeclaration);
    assertEquals(3595, runwayDeclaration.getLDA()); //LDA check
    assertEquals(1496, runwayDeclaration.getTORA()); //TORA check
    assertEquals(1496, runwayDeclaration.getASDA()); //ASDA check
    assertEquals(1496, runwayDeclaration.getTODA()); //TODA check
  }

  /**
   * Tests that a valid input for taking off away from an obstacle is accepted
   */
  @Test
  void takeoffAway() {
    RunwayDeclaration runwayDeclaration = new RunwayDeclaration(3884, 3884, 3884, 3962, 27, "R");
    ObstacleDeclaration obstacleDeclaration = new ObstacleDeclaration(3384, 500, 0, 25, 27);
    RunwayUtils.takeoffAway(runwayDeclaration, obstacleDeclaration, 300);
    assertEquals(3884, runwayDeclaration.getLDA()); //LDA check
    assertEquals(3084, runwayDeclaration.getTORA()); //TORA check
    assertEquals(3084, runwayDeclaration.getASDA()); //ASDA check
    assertEquals(3162, runwayDeclaration.getTODA()); //TODA check
  }
}