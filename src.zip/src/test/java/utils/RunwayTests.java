package java.utils;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import utils.*;

public class RunwayTests {
    /**
     * Tests that a valid input for taking off away from the obstacle is accepted
     */
    @Test
    void takeOffAwayTest() {
        RunwayDeclaration runwayDeclaration = new RunwayDeclaration(3884, 3884, 3884, 3962, 27, "R");
        ObstacleDeclaration obstacleDeclaration = new ObstacleDeclaration(3384, 500, 0, 25, 27);
        RunwayUtils.takeoffAway(runwayDeclaration, obstacleDeclaration, 300);
        assertEquals(3884, runwayDeclaration.getLDA()); //LDA check
        assertEquals(3084, runwayDeclaration.getTORA()); //TORA check
        assertEquals(3084, runwayDeclaration.getASDA()); //ASDA check
        assertEquals(3162, runwayDeclaration.getTODA()); //TODA check
    }


}
