module control {
  requires javafx.controls;
  requires javafx.fxml;
  requires java.xml;
  requires org.controlsfx.controls;
  requires org.junit.jupiter.api;
  requires java.desktop;

  opens view to
      javafx.fxml;

  exports control;
  exports exceptions;
  exports listeners;
  exports model;
  exports utils;
  exports view;
  exports view.components;
  exports view.scenes;
}
