package view;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Accordion;
import javafx.scene.control.Label;
import javafx.scene.control.TitledPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

/**
 * Window for displaying tutorial
 */
public class TutorialWindow extends Application {

  /**
   * Entry point of Tutorial window
   * @param stage primary stage
   */
    @Override
    public void start(Stage stage) {
        stage.setMinWidth(400);
        stage.setMinHeight(800);

        Accordion accordion = new Accordion();

        TitledPane inputs;
        try {
            Image runwaysView = new Image(getClass().getResource("/images/tutorial_runways.png").toExternalForm());
            ImageView viewR = new ImageView(runwaysView);
            viewR.setPreserveRatio(true);
            viewR.fitWidthProperty().bind(stage.widthProperty());
      viewR.fitHeightProperty().bind(stage.heightProperty());
            inputs = new TitledPane("Inputs", viewR);
        } catch (Exception e) {
            Label errorLabel = new Label("UNABLE TO DISPLAY RUNWAYS");
            inputs = new TitledPane("Inputs", errorLabel);
            accordion.getPanes().add(inputs);
        }


        Label outputLabel = new Label("Below the input fields are the outputs.\n"
            + "These are labeled with the numbers below their corresponding name.\n\n\n"
            + "Take-Off Run Available (TORA) - the length of the runway available for take-off. This is the \n"
            + "total distance from the point where an aircraft can commence its take-off to the point where the \n"
            + "runway can no longer support the weight of the aircraft under normal conditions (and where it \n"
            + "should have left the runway during a normal take-off).\n\n"
            + "Take-Off Distance Available (TODA) - the length of the runway (TORA) plus any Clearway\n"
            + "(area beyond the runway that is considered free from obstructions). This is the total distance an \n"
            + "aircraft can safely utilise for its take-off and initial ascent.\n\n"
            + "Accelerate-Stop Distance Available (ASDA) - the length of the runway (TORA) plus any \n"
            + "Stopway (area that is not part of the TORA, but that can be used to safely stop an aircraft in an \n"
            + "emergency). This is the total distance available to the aircraft in case of an aborted take-off.\n\n"
            + "Landing Distance Available (LDA) - the length of the runway available for landing. The start of \n"
            + "this is called the threshold and is typically the same as the start of the TORA. A threshold may be \n"
            + "displaced for operational reasons or because of a temporary obstacle, in which case LDA and \n"
            + "TORA can differ.");
        outputLabel.setWrapText(true);
        TitledPane outputs = new TitledPane("Outputs", outputLabel);

        Label viewLabel = new Label("Initially, the runway view shows the top down runway.\n"
            + "Clicking the 'Change View' button will toggle between the top down and side on views.\n"
            + "The 'Rotate' button automatically rotates the top down view to match the compass heading.\n\n\n\n"
            + "The top down runway contains the following components:\n"
            + "cleared and graded area (blue and green respectively)\n"
            + "\t• runway (with center line)\n"
            + "\t• stopway (grey shaded areas at both ends of the runway)\n\n\n\n"
            + "The side on runway contains the following components:\n"
            + "\t• runway\n"
            + "\t• TOCS/ALS slope (slope inclined at 10 degrees)\n\n\n\n"
            + "Each view will have left and right designators displayed at both ends of the runway.\n"
            + "The 'Rotate' will temporarily adjust the position of the designators to match with the rotated runway.\n"
            + "The runway is displayed as a grey object, and when redeclared, a white plane along with "
            + "the chosen obstacle will be displayed on the view."
            + "The default obstacle is shown as debris, but this can be customised via the Obstacles tab on the menu bar.");
        viewLabel.setWrapText(true);
        TitledPane view = new TitledPane("View", viewLabel);

        Label calcLabel = new Label("Calculations for Landing Over an Obstacle:\n"
                + "LDA:\n"
                + "LDA = LDA - distance from threshold - (height * ALS slope) - strip end \n"
            + "    (ALS slope - if the ALS slope is 1/50 then use 50,\n"
                + "     height - height of obstacle,\n"
            + "     strip end - is 60m)\n\n"
                + "Calculations for Landing Towards Obstacle:\n"
                + "LDA:\n"
                + "LDA = distance from threshold - RESA - strip end\n"
                + "     (RESA (Runway End Safety Area) - is usually and minimum is 240m,\n"
                + "      strip end - is 60m)\n\n"
                + "Calculations for Take-Off Towards Obstacle:\n"
            + "TORA:\n"
            + "TORA = distance + displaced threshold - height * ALS - strip end\n"
                + "     (distance - distance from obstacle to threshold,\n"
                + "      height - height of obstacle,\n"
                + "      ALS - if the ALS slope is 1/50 then use 50,\n"
                + "      strip end - is 60m)\n"
                + "ASDA and TODA:\n"
                + "ASDA = TODA = TORA (same calculations as above)\n\n"
                + "Calculations for Take-Off Away from Obstacle:\n"
                //+ "TORA:\n"
                + "TORA = TORA - distance from threshold - blast protection allowance\n"
                //+ "TODA:\n"
                + "TODA = TODA - distance from threshold - blast protection allowance\n"
                //+ "ASDA:\n"
                + "ASDA = ASDA - distance from threshold - blast protection allowance");

        calcLabel.setWrapText(true);
        TitledPane calculations = new TitledPane("Calculations", calcLabel);

        Label inputRulesLabel = new Label("\t• All inputs have to be greater than or equal to 0 and a number (unless specified otherwise)\n"
            + "\t• TORA has to be lower than ASDA\n"
            + "\t• TORA has to be greater than 1800m\n"
            + "\t• TODA has to be greater than ASDA and TODA is the length of TORA plus the length of any associated clearway; clearway subject to an overall limit of 50% of the TORA, and minimum of 60m\n"
            + "\t• The obstacle height is limited to 30m\n"
            + "\t• LDA has to be greater than blast protection\n"
            + "\t• LDA has to be greater than the threshold away or towards \n"
            + "\t• reshold away or towards has to be greater than -60\n"
            + "\t• Threshold centre has to be less than 75\n");
        inputRulesLabel.setWrapText(true);
        TitledPane inputRules = new TitledPane("Rules for valid inputs",inputRulesLabel);

        Label xmlFileLabel = new Label("Below is an example of an XML file that is used to import a runway into the program.\n "
            + "You must specify the heading in the heading attribute of the runway tag.\n "
            + "This must contain an integer (2 digit format) followed by the designator (L/R).\n "
            + "The values of the LDA, TORA, ASDA and TODA must also be integers and must all be added.\n\n\n\n"
            + "<?xml version = \"1.0\"?>\n" +
                "<declaration>\n" +
                "\t<runway heading = \"HEADING\">\n" +
                "\t\t<lda>VALUE</lda>\n" +
                "\t\t<tora>VALUE</tora>\n" +
                "\t\t<asda>VALUE</asda>\n" +
                "\t\t<toda>VALUE</toda>\n" +
                "\t</runway>\n" +
                "</declaration>");

        TitledPane xmlPane = new TitledPane("XML File Details",xmlFileLabel);
        xmlFileLabel.setWrapText(true);

        accordion.getPanes().addAll(inputs,xmlPane, outputs, view, calculations,inputRules);

        Scene scene = new Scene(accordion, 400, 800);
        stage.setTitle("Tutorial");
        stage.setScene(scene);
        stage.show();
    }

  /**
   * Main method
   * @param args args
   */
  public static void main(String[] args) {
        Application.launch(args);
    }

}
