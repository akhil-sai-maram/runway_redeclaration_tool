package view;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import utils.RunwayDeclaration;
import view.components.RunwayInput;

/**
 * Window for building scene for generating new runways from scratch
 */
public class BuildWindow extends Application{

  /**
   * Imported file
   */
  private String importedFile;

  /**
   * The borderpane to contain RunwayInput VBox
   */
  BorderPane inputPane = new BorderPane();

  /**
   * Main method
   * @param args args
   */
  public static void main(String[] args) {
    Application.launch(args);
  }


  /**
   * Entry point of window
   * @param stage primary stage
   */
  @Override
  public void start(Stage stage) {};

  /**
   * Get the declaration from the build-from-scratch window
   * @param stage the stage to put the scene on
   * @return the declaration that was input
   */
  public RunwayDeclaration getDeclaration(Stage stage) {

    RunwayInput input = new RunwayInput(stage);

    Scene scene = new Scene(input, 500, 500);
    stage.setScene(scene);
    stage.showAndWait();
    return input.returnDeclaration();
  }

}
