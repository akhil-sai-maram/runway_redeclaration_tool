package view.components;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import utils.NotificationDisplay;
import utils.RunwayDeclaration;


/**
 * Generate new runway from declaration.
 * Declaration is either gathered from user input
 * or parsed from existing runway information
 */
public class RunwayInput extends VBox {

    private RunwayDeclaration declaration;
    private boolean success = true;

    //TODO: change to BaseScene and reconfigure for more general,OOP friendly approach
    /**
     * Make the runway input scene including input boxes, labels and actions
     * @param stage the stage to be used
     */
    public RunwayInput(Stage stage) {
        super();

        /*
        All labels correspond to a required value needed to declare runway.
        Textfields and ComboBoxes get user input
         */

        Label headingLabel = new Label("Runway heading:");
        TextField headingInputField = new TextField();

        Label headingExtLabel = new Label("Runway heading extension:");
        ObservableList<String> headingSelector = FXCollections.observableArrayList("R", "L");
        ComboBox<String> headingBox = new ComboBox<>(headingSelector);

        Label ldaLabel = new Label("Landing distance available (m):");
        TextField ldaField = new TextField();

        Label toraLabel = new Label("Take-off run available (m):");
        TextField toraField = new TextField();

        Label todaLabel = new Label("Take-off distance available (m):");
        TextField todaField = new TextField();

        Label asdaLabel = new Label("Accelerate-Stop distance available (m):");
        TextField asdaField = new TextField();

        //Save changes
        Button enter = new Button("enter");

        //Error message is visible when input is invalid
        Label error = new Label("Incorrect input. Please try again.");
        error.setVisible(false);

        //Add all nodes to the object
        this.getChildren().add(headingLabel);
        this.getChildren().add(headingInputField);
        this.getChildren().add(headingExtLabel);
        this.getChildren().add(headingBox);
        this.getChildren().add(ldaLabel);
        this.getChildren().add(ldaField);
        this.getChildren().add(toraLabel);
        this.getChildren().add(toraField);
        this.getChildren().add(todaLabel);
        this.getChildren().add(todaField);
        this.getChildren().add(asdaLabel);
        this.getChildren().add(asdaField);
        this.getChildren().add(enter);
        this.getChildren().add(error);

        headingInputField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                headingInputField.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });

        ldaField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                ldaField.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });

        todaField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                todaField.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });

        toraField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                toraField.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });

        asdaField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                asdaField.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });

        /*
        When enter button is clicked, values from user input are gathered and parsed
        to be stored as relevant values of RunwayDeclaration.
        Runway Declaration then used to update existing view and error presented if unsuccessful.
         */
        enter.setOnAction(event -> {
            try {
                String headingString = headingInputField.getText();
                int headingInt = Integer.parseInt(headingString);
                String headingExt = headingBox.getValue();
                int lda = Integer.parseInt(ldaField.getText().replace(",", ""));
                int tora = Integer.parseInt(toraField.getText().replace(",", ""));
                int toda = Integer.parseInt(todaField.getText().replace(",", ""));
                int asda = Integer.parseInt(asdaField.getText().replace(",", ""));


                declaration = new RunwayDeclaration(lda, tora, toda, asda, headingInt, headingExt);
                error.setVisible(false);
            } catch (Exception e) {
                error.setVisible(true);
                success = false;
            } finally {
                NotificationDisplay.notifyNewBuild(success);
                stage.close();
            }
        });
    }

    /**
     * Get the runway declaration
     * @return declaration
     */
    public RunwayDeclaration returnDeclaration() {
        return declaration;
    }


    /**
     * Static method to parse information from existing runway information and update declaration
     * @param runwayInfo Existing runway configuration string containing airport name and runway information
     * @return Runway Declaration
     */
    public static RunwayDeclaration existingDeclaration(String runwayInfo) {
        //All runwayInfo Strings come in the form:
        //"AIRPORT_NAME Runway (LEFT_DESIGNATOR RIGHT_DESIGNATOR): RUNWAY_LENGTH metres by RUNWAY_WIDTH metres"
        if (runwayInfo.equals("Runway Configuration")) {
            NotificationDisplay.notifyExistingBuild(runwayInfo);
            return null;
        }

        //Parse relevant information from string
        int l = runwayInfo.length();
        var split = runwayInfo.split(" ");
        int distance = Integer.parseInt(split[4]);
        int heading = Integer.parseInt(split[2].substring(1,split[2].length()-1));
        String designator = split[2].substring(split[2].length()-1);

        try {
            //Use runway info to update existing view
            RunwayDeclaration runwayDeclaration = new RunwayDeclaration(distance,distance,distance,distance,heading,designator);
            NotificationDisplay.notifyExistingBuild("\n"+runwayInfo.substring(0,l-26));
            return runwayDeclaration;
        } catch (Exception e) {
            //Display pop-up to alert user of invalid runway
            Alert error = new Alert(AlertType.ERROR);
            error.setTitle("Import error");
            error.setContentText("Error - unable to import existing runway information");
            error.show();
        }
        return null;
    }
}