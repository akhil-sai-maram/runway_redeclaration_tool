package view.components;

import javafx.beans.property.SimpleStringProperty;
import javafx.geometry.Pos;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.RowConstraints;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;

/**
 * Blueprint to create basic components needed for displaying the runway
 * Additional classes must extend this class to include additional relevant components
 */
public class RunwayDesign implements RunwayComponents{

  /**
   * Runway dimensions for view
   */
  protected final float runwayLength;
  protected final float runwayWidth;

  /**
   * Runway designators on both sides of runway
   */
  protected final SimpleStringProperty designatorL = new SimpleStringProperty();
  protected final SimpleStringProperty designatorR = new SimpleStringProperty();
  protected final SimpleStringProperty designatorExtensionL = new SimpleStringProperty();
  protected final SimpleStringProperty designatorExtensionR = new SimpleStringProperty();

  /**
   * runway components and gridpane containing them
   */
  protected Rectangle runway;
  protected GridPane pane;
  protected Boolean headingRight;

  /**
   * Entry point to initialise components for building the runway template
   * @param length length of runway
   * @param width width of runway
   * @param leftIndicator left designator
   * @param rightIndicator right designator
   */
  public RunwayDesign(float length, float width, SimpleStringProperty left, SimpleStringProperty right, SimpleStringProperty leftIndicator, SimpleStringProperty rightIndicator) {
    runwayLength = length;
    runwayWidth = width;
    designatorL.bind(left);
    designatorR.bind(right);
    designatorExtensionL.set(leftIndicator.getValue());
    designatorExtensionR.set(rightIndicator.getValue());
    headingRight = true;
  }

  /**
   * Accessor method for length of runway
   * @return runway length
   */
  public float getRunwayLength() {
    return runwayLength;
  }

  /**
   * Accessor method for width of runway
   * @return runway width
   */
  public float getRunwayWidth() {
    return runwayWidth;
  }

  /**
   * Accessor method for left designator
   * @return left designator
   */
  public String getDesignatorL() {
    return designatorL.get();
  }

  /**
   * Accessor method for right designator
   * @return right designator
   */
  public String getDesignatorR() {
    return designatorR.get();
  }

  /**
   * Getter for the left heading indicator
   * @return left designator
   */
  public String getDesignatorIndicatorL() { return designatorExtensionL.get(); }

  /**
   * Getter for the left heading indicator
   * @return right designator
   */
  public String getDesignatorIndicatorR() { return designatorExtensionR.get(); }

  /**
   * Build the relevant components to display a basic runway
   */
  public void build() {

    //build runway represented as a rectangle
    runway = new Rectangle();
    runway.setWidth(runwayWidth);
    runway.setHeight(runwayLength);
    runway.setRotate(90);
    runway.setFill(Color.GREY);

    pane = new GridPane();
    pane.setAlignment(Pos.CENTER);

    //Gridpane set up
    RowConstraints rConstraints = new RowConstraints(runwayWidth);
    ColumnConstraints cConstraints = new ColumnConstraints(runwayLength/6);
    for (int i = 0; i < 10; i++) {
      pane.getColumnConstraints().add(cConstraints);
    }
    for (int i = 0; i < 7; i++) {
      pane.getRowConstraints().add(rConstraints);
    }

    //Left and right designators
    Text left = new Text();
    left.textProperty().bind(designatorL);
    left.getStyleClass().add("-fx-text-fill: white;");
    Text right = new Text();
    right.textProperty().bind(designatorR);
    right.getStyleClass().add("-fx-text-fill: white;");
    Text leftInd = new Text();
    leftInd.textProperty().set(designatorExtensionL.getValue());
    leftInd.getStyleClass().add("-fx-text-fill: white;");
    Text rightInd = new Text();
    rightInd.textProperty().set(designatorExtensionR.getValue());
    rightInd.getStyleClass().add("-fx-text-fill: white;");

    //HBox to contain designators
    HBox labels = new HBox(runwayLength-35,left,right);
    pane.add(labels,2,3,7,1);
    labels.setTranslateY(160);

    HBox extensions = new HBox(runwayLength-35,leftInd,rightInd);
    pane.add(extensions,2,3,7,1);
    extensions.setTranslateY(170);
  }

  /**
   * Implementation of interface method to change colour
   * @param color colour to change
   */
  @Override
  public void changeColour(Color color) {
    runway.setFill(color);
  }

  /**
   * Accessor method for gridpane
   * @return gridpane containing runway view
   */
  public GridPane getPane() {
    return pane;
  }

  /**
   * Accessor method for runway
   * @return runway object
   */
  public Rectangle getRunway() {
    return runway;
  }

  //To be overridden in TopDown and SideOnViews
  //On a TopDown Runway, object switches sides.
  //On a SideOn Runway, object switches

  /**
   * Changes direction of the plane and orientation of any obstacles placed.
   * @param moveRight is the new variable that checks if you are moving rightwards.
   */
  public void changeHeadingDirection(boolean moveRight) {
    headingRight = moveRight;
  }

  /**
   * Obstacle is added behind where the plane is expected to be if it was going from left to right.
   * in all iterations, it will be reversed if heading right is false. To be overridden in the other
   * children who have inherited RunwayDesign
   * @param distance is the distance between the plane and the obstacle
   * @param runwayDistance is the distance for the plane to take off or to land.
   */
  public void addObstacleBehind(int distance, int runwayDistance){}

  /**
   * Obstacle is added in front where the plane is expected to be if it was going from left to right.
   * To be overridden in the other children who have inherited RunwayDesign.
   * @param distance distance between obstacle and plane
   */
  public void addObstacleLandTo(int distance) {}

  /**
   * Obstacle added where it would be positioned when the plane is taking off towards it
   * @param obstacleHeight of the obstacle
   * @param distance between the obstacle and plane
   */
  public void addObstacleTakeTo(int obstacleHeight, int distance) {}

  /**
   * Obstacle added where it would be positioned when the plane is taking off away from it
   * @param obstacleDistance the distance between the plane and obstacle
   * @param runwayDistance between the obstacle and plane
   */
  public void addObstacleTakeAway(int obstacleDistance,int runwayDistance){}

  /**
   * Obstacle added where it would be positioned when the plane is landing over it
   * @param obstacleDistance the object height
   * @param runwayDistance distance available
   */
  public void addObstacleLandOver(int obstacleDistance,int runwayDistance){}

  /**
   * Remove obstacles
   */
  public void clearRunwayObstacles() {}

  /**
   * Sets which direction the plane should face
   * @param angle the angle to rotate by
   */
  public void setRotate(double angle) {}

  /**
   * Changes the image of the obstacle
   * @param filename of the obstacle image
   */
  public void changeObstacle(String filename){}

}
