package view.components;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;

/**
 * Factory class generating a plane object
 */
public class Plane implements RunwayComponents{

  /**
   * Plane object
   */
  ImageView plane;

  /**
   * Default plane
   */
  public Plane() {
    Image planeImage = new Image(this.getClass().getResource("/images/SPlaneTopDown.png").toExternalForm());
    plane = new ImageView(planeImage);
  }

  /**
   * Constuctor to make a plane from an image
   * @param imageFile the image
   */
  public Plane(String imageFile) {
    Image planeImage = new Image(imageFile);
    plane = new ImageView(planeImage);
  }

  /**
   * Interface method to change colour
   * @param color new colour to change
   */
  @Override
  public void changeColour(Color color) {

  }

  /**
   * Build plane by defining dimensions
   */
  public void build() {
    //TODO: Alter dimensions
    plane.setFitWidth(60d);
    plane.setFitHeight(50d);
  }

  /**
   * Rotate plane
   * @param angle angle of where plane is pointing
   */
  public void setRotate(double angle) {
    plane.setRotate(angle);
  }

  /**
   * Use different image for plane
   * @param filePath path for new plane
   */
  public void changeImage(String filePath) {
    Image newDesign =  new Image(filePath);
    plane = new ImageView(newDesign);
    //Rebuild using new plane object
    build();
  }

  /**
   * Getter method to return plane object
   * @return new plane
   */
  public ImageView getPlane() {
    return plane;
  }

  /**
   * Set the plane size
   * @param height the height
   * @param width the width
   */
  public void setSize(double height, double width) {

    plane.setFitHeight(height);
    plane.setFitWidth(width);

  }

}
