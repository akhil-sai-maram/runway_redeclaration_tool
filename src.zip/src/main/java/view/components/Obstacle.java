package view.components;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;

/**
 * Factory class to build obstacle
 */
public class Obstacle implements RunwayComponents{



  /**
   * Shape representing obstacle
   */
  ImageView obstacle;

  /**
   * Default Obstacle constructor will provide debris image
   */
  public Obstacle() {
    Image debrisImage = new Image(this.getClass().getResource("/images/debris.png").toExternalForm());
    obstacle = new ImageView(debrisImage);
  }

  public Obstacle(String imageFile) {
    Image obstacleImage = new Image(imageFile);
    obstacle = new ImageView(obstacleImage);
  }

  /**
   * Change colour of obstacle
   * @param color new colour of obstacle
   */
  @Override
  public void changeColour(Color color) {

  }

  /**
   * Build the obstacle
   */
  @Override
  public void build() {
    obstacle.setFitWidth(60d);
    obstacle.setFitHeight(50d);
  }

  /**
   * Use different image for plane
   * @param filePath path for new plane
   */
  public void changeImage(String filePath) {
    Image newDesign =  new Image(filePath);
    obstacle = new ImageView(newDesign);
    //Rebuild using new plane object
    build();
  }

  /**
   * Accessor method for obstacle
   * @return ImageView representing obstacle
   */
  public ImageView getDesign() {return obstacle;}

  public void setSize(int height, int width) {
    obstacle.setFitHeight(height);
    obstacle.setFitWidth(width);
  }
}
