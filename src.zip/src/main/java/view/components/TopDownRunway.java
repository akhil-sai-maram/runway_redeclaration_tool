package view.components;

import control.App;
import javafx.beans.property.SimpleStringProperty;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Line;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;

/**
 * Class to generate top down view of runway with required components
 */
public class TopDownRunway extends RunwayDesign {

  /**
   * All properties of top down views required
   */
  private Rectangle runwayBackground;
  private Rectangle clearedArea;
  private Polygon clearedAreaTop, clearedAreaBottom;
  private Rectangle leftArea, rightArea;
  private Line centerLine;
  private HBox obstaclePositioning;
  private Obstacle obstacle;
  private Plane plane;

  private boolean rotated;

  /**
   * Variable to scale view based on runway length
   */
  //Used to change distances between real values and model scale
  private float scaleFactor;

  /**
   * Constructor
   * @param length length of runway
   * @param width width of runway
   * @param left designator
   * @param right designator
   * @param leftExtension 'L'
   * @param rightExtension 'R'
   */
  public TopDownRunway(float length, float width, SimpleStringProperty left, SimpleStringProperty right, SimpleStringProperty leftExtension, SimpleStringProperty rightExtension) {
    super(length, width, left, right, leftExtension, rightExtension);
    //To change later but for now am using scale factor of 3884 total runway
    int totalRunway = App.getInstance().getRunwayDeclaration().getASDA();
    scaleFactor = getRunwayLength()/totalRunway;//3884 is the default total runway available.

    rotated = false;

  }

  /**
   * Build top down view with required components
   */
  @Override
  public void build() {
    super.build();

    //default: runwayLength = 250f
    //default: runwayWidth = 40f
    //Create cleared and graded areas
    runwayBackground = new Rectangle((5*runwayLength)/3, 7*runwayWidth);
    runwayBackground.setFill(Color.GREEN);

    clearedArea = new Rectangle((4*runwayLength)/3, 3*runwayWidth);
    clearedArea.setFill(Color.LIGHTBLUE);

    //Generic coordinates for trapeziums to be placed around cleared area
    double coordinates[] = {
        50.0,30.0,
        200.0,30.0,
        runwayLength,runwayWidth+20.0,
        0.0,runwayWidth+20.0
    };

    //Generate trapezium and translate it to appropriate position
    clearedAreaTop = new Polygon(coordinates);
    clearedAreaTop.setFill(Color.LIGHTBLUE);
    clearedAreaTop.setStroke(Color.TRANSPARENT);
    clearedAreaTop.setTranslateY(-1 * clearedArea.getWidth()/4.45);

    //Generate trapezium and translate it to appropriate position
    clearedAreaBottom = new Polygon(coordinates);
    clearedAreaBottom.setFill(Color.LIGHTBLUE);
    clearedAreaBottom.setStroke(Color.TRANSPARENT);
    clearedAreaBottom.setTranslateY(-25);
    clearedAreaBottom.rotateProperty().set(180);

    //Generate dashed line representing center line
    centerLine = new Line(0, runwayWidth/2, runwayLength - (runwayLength/3), runwayWidth/2);
    centerLine.translateXProperty().set((runwayLength/6));
    centerLine.getStrokeDashArray().addAll(15d, 15d);
    centerLine.setStroke(Color.WHITE);
    centerLine.setStrokeWidth(2.3);

    //Graded areas on left and right of runway
    leftArea = new Rectangle(runwayLength/6,runwayWidth);
    rightArea = new Rectangle(runwayLength/6,runwayWidth);

    //Safely add stopway to ends of runway
    try {
      Image fill = new Image(getClass().getResource("/images/horizontalFill").toExternalForm());
      leftArea.setFill(new ImagePattern(fill));
      rightArea.setFill(new ImagePattern(fill));
    } catch (Exception e) {
      Alert alert = new Alert(AlertType.ERROR, "An error has occurred. Unable to retrieve image file.");
      alert.setTitle("An Error Has Occurred");
    }

    //Add elements to gridpane
    pane.add(runwayBackground, 0, 0, 10, 7);
    pane.add(clearedArea,1,2,8,3);
    pane.add(clearedAreaTop,2,1,6,5);
    pane.add(clearedAreaBottom,2,5,6,5);
    pane.add(runway,2,3,6,1);
    pane.add(leftArea,2,3,1,1);
    pane.add(rightArea,7,3,1,1);
    pane.add(centerLine,2,3,6,1);
    // don't mess with runway Halignment because it will make the runway go off place
    GridPane.setHalignment(runway, HPos.CENTER);

    // didn't add to gridpane since we are changing to images
    //ALso need to add way to change size of obstacle
    obstacle = new Obstacle();
    obstacle.setSize(30,40);

    //Build and add plane to runway
     plane = new Plane();
     plane.setSize(60d,70d);

    //HBox to update position of HBox
    obstaclePositioning = new HBox();
    var transparentRect = new Rectangle(runwayLength-2*runwayLength/6, 20f, Color.TRANSPARENT);
    obstaclePositioning.getChildren().add(transparentRect);

    //Unless HBox can be replaced instead, I will be using HBox with transparent rectangles to get positions
    pane.add(obstaclePositioning,3,3,6,1);
    obstaclePositioning.setAlignment(Pos.CENTER);
    //pane.getChildren().addAll(centerLine,obstaclePositioning);
    HBox.setMargin(obstaclePositioning,new Insets(200));
  }

  /**
   * Accessor method to get the line in center
   * @return line object
   */
  public Line getCenterLine() {
    return centerLine;
  }

  //Takes the distance to the object and puts in between

  //TODO: change obstacle positioning coordinate when headingRight switches

  /**
   * Update position of obstacle based on distance and height provided
   * @param height height of obstacle
   * @param distance distance of obstacle from runway
   */
  @Override
  public void addObstacleTakeTo(int height, int distance ) {
    obstaclePositioning.getChildren().clear();
    //distancing object used to check runway distance, currently orange for
    Rectangle distancing = new Rectangle(distance*scaleFactor*0.7, 20,Color.TRANSPARENT);
    if (headingRight) {
      //pane.add(obstaclePositioning,2,3,6,1);
      obstaclePositioning.getChildren().addAll(plane.getPlane(),distancing,obstacle.getDesign());
    } else {
      //pane.add(obstaclePositioning,3,3,6,1);
      obstaclePositioning.getChildren().addAll(obstacle.getDesign(),distancing,plane.getPlane());
    }
  }

  /**
   * Update position of obstacle based on distance provided
   * @param distance distance from plane to object
   */
  @Override
  public void addObstacleLandTo(int distance) {
    obstaclePositioning.getChildren().clear();
    //distancing object used to check runway distance, currently orange for
    var distancing = new Rectangle(distance*scaleFactor*0.7, 20,Color.TRANSPARENT);
    if (headingRight) {
      obstaclePositioning.getChildren().addAll(plane.getPlane(),distancing,obstacle.getDesign());
    } else {
      obstaclePositioning.getChildren().addAll(obstacle.getDesign(),distancing,plane.getPlane());
    }
  }

  /**
   * Get the distance from obstacle to plane and the distance from plane to runway
   * @param blastDistance minimal distance to ensure plane's force does not harm object
   * @param runwayDistance distance on runway
   */
  @Override
  public void addObstacleTakeAway(int blastDistance,int runwayDistance) {
    obstaclePositioning.getChildren().clear();
    Rectangle obstacleToPlane = new Rectangle(blastDistance*scaleFactor*0.7, 20,Color.TRANSPARENT);
    Rectangle planeRun = new Rectangle(runwayDistance*scaleFactor*0.7,20,Color.TRANSPARENT);
    if (headingRight){
      obstaclePositioning.getChildren().addAll(obstacle.getDesign(),obstacleToPlane,
          plane.getPlane(),planeRun);
    } else {
      obstaclePositioning.getChildren().addAll(planeRun,plane.getPlane(),obstacleToPlane,
          obstacle.getDesign());
    }
  }

  /**
   * Update position of obstacle based on height of obstacle and available distance
   * @param obstacleHeight height of obstacle
   * @param runwayDistance distance available
   */
  @Override
  public void addObstacleLandOver(int obstacleHeight,int runwayDistance) {
    obstaclePositioning.getChildren().clear();
    Rectangle obstacleToPlane = new Rectangle(50*obstacleHeight*scaleFactor*0.7 -
        obstacle.getDesign().getFitWidth(), 20,Color.TRANSPARENT);
    Rectangle planeRun = new Rectangle(runwayDistance*scaleFactor*0.7,20,Color.TRANSPARENT);
    if (headingRight){
      obstaclePositioning.getChildren().addAll(planeRun,obstacleToPlane,obstacle.getDesign(),
          plane.getPlane());
    } else {
      obstaclePositioning.getChildren().addAll(plane.getPlane(),obstacle.getDesign(),
          obstacleToPlane,planeRun);
    }
  }

  /**
   * Remove items on HBox
   */
  @Override
  public void clearRunwayObstacles() {
    obstaclePositioning.getChildren().clear();
  }

  /**
   * Rotate method
   * @param angle angle to rotate plane
   */
  @Override
  public void setRotate(double angle) {
    plane.setRotate(angle);
  }

  /**
   * Method to rotate the runway
   */
  public void rotate() {
    int dL = Integer.parseInt(getDesignatorL());
    int dR = Integer.parseInt(getDesignatorR());
    int lowerHeading = Math.min(dL, dR);

    if(rotated) {
      rotated = false;
      pane.setRotate(0);
      for (Node n : pane.getChildren()) {
        if (!(n instanceof HBox)) continue;
        if (((HBox) n).getChildren().stream().noneMatch(node -> node instanceof Text)) continue;
        for (Node n1 : ((HBox) n).getChildren()) {
          n1.setRotate(0);
        }
      }
    } else {
      rotated = true;
      int angle = 90 + 10 * lowerHeading;
      pane.setRotate(angle);
      for (Node n : pane.getChildren()) {
        if (!(n instanceof HBox)) continue;
        if (((HBox) n).getChildren().stream().noneMatch(node -> node instanceof Text)) continue;
        for (Node n1 : ((HBox) n).getChildren()) {
          n1.setRotate(-angle);
        }
      }
    }

  }

  /**
   * Changes the image of the obstacle
   * @param filename of the obstacle image
   */
  @Override
  public void changeObstacle(String filename) {
    int pos = obstaclePositioning.getChildren().indexOf(obstacle.getDesign());
    obstacle.changeImage(filename);
    if (pos != -1) {
      if (filename.equals(this.getClass().getResource("/images/SPlaneTopDown.png").toExternalForm())){
        obstacle.setSize(50,60);
      }else {
        obstacle.setSize(30, 40);
      }
      obstaclePositioning.getChildren().set(pos, obstacle.getDesign());
    }
  }

}
