package view.components;

import control.App;
import javafx.beans.property.SimpleStringProperty;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;

/**
 * Class to build the side on runway and its components
 */
public class SideOnRunway extends RunwayDesign {

  private Obstacle obstacle;
  private Line slope;
  private Plane plane;
  private HBox obstaclePositioning;
  private float scaleFactor;


  /**
   * Constructor for the side on runway
   * @param length the runway length
   * @param left left designator
   * @param right right designator
   * @param leftExt left indicator
   * @param rightExt right indicator
   */
  public SideOnRunway(float length, SimpleStringProperty left, SimpleStringProperty right, SimpleStringProperty leftExt, SimpleStringProperty rightExt) {
    super(length, 5, left, right, leftExt, rightExt);
    int totalRunway = App.getInstance().getRunwayDeclaration().getASDA();
    scaleFactor = getRunwayLength()/totalRunway;
  }

  /**
   * Build the side on runway and its components
   */
  @Override
  public void build() {
    super.build();
    slope = new Line(100, 1, 1, 10);

    pane.add(runway,2,3,6,1);
    // don't mess with runway Halignment because it will make the runway go off place
    GridPane.setHalignment(runway, HPos.CENTER);


    //need to change obstacle to be same as height.
    //Obstacle(5,20)
    obstacle = new Obstacle();
    //make sure to run obstacle.build when instantiating a new obstacle so that you can define the size.
    obstacle.build();
    obstacle.setSize(22, 22);

    obstaclePositioning = new HBox();
    pane.add(obstaclePositioning,2,3,6,1);

    plane = new Plane(this.getClass().getResource("/images/planeSideOn.png").toExternalForm());
    plane.build();
    plane.getPlane().setTranslateY(-17);
    GridPane.setMargin(obstaclePositioning, new Insets(0,0,5,0));
    //Add insets to go above line and on the right.
  }

  /**
   * Positions the assets in the case of a landing towards
   * @param distance between the obstacle and plane
   */
  @Override
  public void addObstacleLandTo(int distance){

    obstaclePositioning.getChildren().clear();
    Line slopeL = calculateTOCSLineLeft(20);
    Line slopeR = calculateTOCSLineRight(20);
    //distancing object used to check runway distance, currently orange for clarity
    var distancing = new Rectangle(distance*scaleFactor*0.8, 20,Color.TRANSPARENT);

    if (headingRight) {
      obstaclePositioning.getChildren().addAll(plane.getPlane(),slopeL,distancing,obstacle.getDesign());
      plane.getPlane().setTranslateY(-17);
     obstacle.getDesign().setTranslateY(-5);

    } else {
      obstaclePositioning.getChildren().addAll(obstacle.getDesign(),distancing,slopeR,plane.getPlane());
      plane.getPlane().setTranslateY(-17);
     obstacle.getDesign().setTranslateY(-5);

    }
  }

  /**
   * Positions the assets in the case of a landing over
   * @param obstacleHeight the height of the obstacle
   * @param runwayDistance between the obstacle and plane
   */
  @Override
  public void addObstacleLandOver(int obstacleHeight,int runwayDistance) {
    obstaclePositioning.getChildren().clear();
    Rectangle planeRun = new Rectangle(runwayDistance*scaleFactor*0.8,20,Color.TRANSPARENT);
    //obstacle = new Obstacle();
    if (headingRight){
      slope = calculateTOCSLineRight(obstacleHeight);
      obstaclePositioning.getChildren().addAll(planeRun,slope,obstacle.getDesign(),plane.getPlane());
      plane.getPlane().setTranslateY(-17);
     obstacle.getDesign().setTranslateY(-5);

    } else {
      slope = calculateTOCSLineLeft(obstacleHeight);
      obstaclePositioning.getChildren().addAll(plane.getPlane(),obstacle.getDesign(),slope, planeRun);
      plane.getPlane().setTranslateY(-17);
     obstacle.getDesign().setTranslateY(-5);

    }
  }

  /**
   * Positions the assets in the case of a take-off towards
   * @param height of the obstacle
   * @param distance between the obstacle and plane
   */
  @Override
  public void addObstacleTakeTo(int height, int distance ) {
    obstaclePositioning.getChildren().clear();
    Rectangle distancing = new Rectangle(distance*scaleFactor*0.8, 20,Color.TRANSPARENT);
    if (headingRight) {
      slope = calculateTOCSLineRight(height);
      obstaclePositioning.getChildren().addAll(plane.getPlane(),distancing,
          slope,obstacle.getDesign());
      plane.getPlane().setTranslateY(-17);
     obstacle.getDesign().setTranslateY(-5);

    } else {
      slope = calculateTOCSLineLeft(height);
      obstaclePositioning.getChildren().addAll(obstacle.getDesign(),slope,
          distancing,plane.getPlane());
      plane.getPlane().setTranslateY(-17);
     obstacle.getDesign().setTranslateY(-5);

    }
  }

  /**
   * Positions the assets in the case of a take-off away
   * @param blastDistance the blast protection distance
   * @param runwayDistance between the obstacle and plane
   */
  @Override
  public void addObstacleTakeAway(int blastDistance,int runwayDistance) {
    obstaclePositioning.getChildren().clear();
    Rectangle obstacleToPlane = new Rectangle(blastDistance*scaleFactor*0.8, 20,Color.TRANSPARENT);
    Rectangle planeRun = new Rectangle(runwayDistance*scaleFactor*0.8,20,Color.TRANSPARENT);
    if (headingRight){
      obstaclePositioning.getChildren().addAll(obstacle.getDesign(),obstacleToPlane,
          plane.getPlane(),planeRun,calculateTOCSLineRight(20));
     obstacle.getDesign().setTranslateY(-5);
      plane.getPlane().setTranslateY(-17);
    } else {
      obstaclePositioning.getChildren().addAll(calculateTOCSLineLeft(20),planeRun,
          plane.getPlane(),obstacleToPlane, obstacle.getDesign());
      plane.getPlane().setTranslateY(-17);
     obstacle.getDesign().setTranslateY(-5);

    }
  }

  /**
   * Calculates the sizes of the line to get a 1:50 representation of the TOCS angle,
   * In order to make the scale clearer, the angle won't be represented in actuality to be 1:50, as
   * that becomes too small.
   * @param  obstacleHeight height of obstacle for TOCS to calculate
   * @return TOCS/ALS slope
   */
  public Line calculateTOCSLineLeft(int obstacleHeight) {
    Line slope = new Line (obstacleHeight*50*scaleFactor,obstacleHeight,0,0);
    return slope;
  }

  /**
   * Calculates the sizes of the line to get a 1:50 representation of the TOCS angle,
   * In order to make the scale clearer, the angle won't be represented in actuality to be 1:50, as
   * that becomes too small.
   * @param  obstacleHeight height of obstacle for TOCS to calculate
   * @return center line object
   */
  public Line calculateTOCSLineRight(int obstacleHeight) {
    return new Line (1,1,obstacleHeight*-50*scaleFactor,obstacleHeight);
  }

  /**
   * Remove obstacles
   */
  @Override
  public void clearRunwayObstacles() {
    obstaclePositioning.getChildren().clear();
  }

  /**
   * Sets which direction the plane should face
   * @param angle the plane should be facing
   */
  @Override
  public void setRotate(double angle) {
    if (angle* -1 < 0) {
      plane.changeImage(this.getClass().getResource("/images/planeSideOnR.png").toExternalForm());
    } else {
      plane.changeImage(this.getClass().getResource("/images/planeSideOn.png").toExternalForm());
    }
  }

  /**
   * Changes the image on the obstacle
   * @param filename of the obstacle image
   */
  @Override
  public void changeObstacle(String filename) {
    int pos = obstaclePositioning.getChildren().indexOf(obstacle.getDesign());
    obstacle.changeImage(filename);
    if (pos != -1) {
      obstaclePositioning.getChildren().set(pos, obstacle.getDesign());
      obstacle.getDesign().setTranslateY(-5);

    }

  }
}
