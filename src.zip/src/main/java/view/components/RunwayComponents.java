package view.components;

import javafx.scene.paint.Color;

/**
 * An interface to be used for the components making up the runway
 */
public interface RunwayComponents {

  /**
   * Change the colour of the component
   * @param color the colour
   */
  void changeColour(Color color);

  /**
   * Build the component
   */
  void build();
}
