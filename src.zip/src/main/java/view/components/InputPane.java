package view.components;

import control.App;
import javafx.beans.binding.Bindings;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import model.RunwayModel.DeclarationType;
import utils.NotificationDisplay;
import utils.ObstacleDeclaration;
import utils.RunwayDeclaration;
import view.ToolWindow;
import view.scenes.BaseScene;

/**
 * A class to construct the input pane for inputs
 */
public class InputPane extends VBox {

  public ToolWindow window;
  public BaseScene mainScene;
  private int rotation = 0;
  private SimpleIntegerProperty prevLDA;
  private SimpleIntegerProperty prevTORA;
  private SimpleIntegerProperty prevASDA;
  private SimpleIntegerProperty prevTODA;
  private ComboBox<Integer> headingBox;

  /**
   * Constructs the pane in which obstacles on the runway can be redeclared,
   * and outputs the new distances that we can use.
   * @param window Takes in the window of the stage to see for any manipulations
   */
  public InputPane(ToolWindow window, BaseScene scene) {
    super();

    ObservableList<DeclarationType> options = FXCollections.observableArrayList(DeclarationType.LANDING_TOWARD,
        DeclarationType.LANDING_OVER, DeclarationType.TAKEOFF_OVER, DeclarationType.TAKEOFF_AWAY);
    ComboBox<DeclarationType> declarationType = new ComboBox<>(options);
    declarationType.setPromptText("Select a mode...");

    this.window = window;
    this.mainScene = scene;

    //Labels and textfields corresponding to relevant input
    Label modeLabel = new Label("Declaration mode:");

    Label headingLabel = new Label("Runway heading:");

    Label thresholdTowardLabel = new Label("Plane to obstacle (m):");
    TextField thresholdTowardField = new TextField();

    Label thresholdAwayLabel = new Label("Obstacle to opposite runway end (m):");
    TextField thresholdAwayField = new TextField();

    Label thresholdCentreLabel = new Label("Obstacle to centre (m):");
    TextField thresholdCentreField = new TextField();

    Label obstacleHeightLabel = new Label("Obstacle Height (m):");
    TextField obstacleHeightField = new TextField();

    Label blastProtectionLabel = new Label("Blast Protection (m):");
    TextField blastProtectionField = new TextField();

    //Buttons to save or clear input
    Button redeclare = new Button("Redeclare");
    Button clear = new Button("Clear");

    Alert alert = new Alert(AlertType.ERROR, "One or more of the values you have "
        + "input is incorrect");

    this.getChildren().add(modeLabel);
    this.getChildren().add(declarationType);
    this.getChildren().add(headingLabel);
    setHeadingOptions(getRunwayValues().getHeading());
    this.getChildren().add(thresholdTowardLabel);
    this.getChildren().add(thresholdTowardField);
    this.getChildren().add(thresholdAwayLabel);
    this.getChildren().add(thresholdAwayField);
    this.getChildren().add(thresholdCentreLabel);
    this.getChildren().add(thresholdCentreField);
    this.getChildren().add(obstacleHeightLabel);
    this.getChildren().add(obstacleHeightField);
    this.getChildren().add(blastProtectionLabel);
    this.getChildren().add(blastProtectionField);
    this.getChildren().add(redeclare);
    this.getChildren().add(clear);

    redeclare.setOnAction(event -> {
      try {
        //Attempt to parse values entered by user
        int heading = headingBox.getValue();
        int toward = Integer.parseInt(thresholdTowardField.getText().replace(",", ""));
        int away = Integer.parseInt(thresholdAwayField.getText().replace(",", ""));
        int centre = Integer.parseInt(thresholdCentreField.getText().replace(",", ""));
        int height = Integer.parseInt(obstacleHeightField.getText().replace(",", ""));
        ObstacleDeclaration declaration = new ObstacleDeclaration(toward, away, centre, height, heading);
        int blast = Integer.parseInt(blastProtectionField.getText().replace(",", ""));

        RunwayDesign tdRunway = mainScene.getRunway();
        try {
          //gets value before change is sent
          int currentLDA = getRunwayValues().getLDAProperty().getValue();
          int currentTORA = getRunwayValues().getTORAProperty().getValue();
          int currentASDA = getRunwayValues().getASDAProperty().getValue();
          int currentTODA = getRunwayValues().getTODAProperty().getValue();
          this.window.redeclare(declaration, declarationType.getValue(), blast);
          if (!(currentLDA == getRunwayValues().getLDAProperty().getValue() &&
              currentTORA == getRunwayValues().getTORAProperty().getValue() &&
              currentASDA == getRunwayValues().getASDAProperty().getValue() &&
              currentTODA == getRunwayValues().getTODAProperty().getValue()) ) {
            prevLDA.set(currentLDA);
            prevTORA.set(currentTORA);
            prevASDA.set(currentASDA);
            prevTODA.set(currentLDA);
          }

          if (getRunwayValues().getHeading() == heading) {
            tdRunway.changeHeadingDirection(false);
            rotation = 1;
          } else {
            tdRunway.changeHeadingDirection(true);
            rotation = -1;
          }


          //Chooses between having obstacle in front or behind plane, then tries to input distances for these points
          DeclarationType flightType = declarationType.getValue();
          switch (flightType) {
            case LANDING_TOWARD -> {
              tdRunway.setRotate(-90 * rotation);
              tdRunway.addObstacleLandTo(getRunwayValues().getLDA());
            }
            case LANDING_OVER -> {
              tdRunway.setRotate(90 * rotation);
              tdRunway.addObstacleLandOver(height, getRunwayValues().getLDA());
            }
            case TAKEOFF_OVER -> {
              tdRunway.setRotate(-90 * rotation);
              tdRunway.addObstacleTakeTo(height ,getRunwayValues().getTORA());
            }
            case TAKEOFF_AWAY -> {
              tdRunway.setRotate(90 * (-rotation));
              tdRunway.addObstacleTakeAway(blast, getRunwayValues().getTORA());
            }
          }
          NotificationDisplay.notifyDeclaration();
        } catch (Exception e) {
          tdRunway.clearRunwayObstacles();
        }
      } catch (Exception e) {
        alert.showAndWait();
      }
    });

    clear.setOnAction(event -> {
      //Clear all fields
      declarationType.getSelectionModel().clearSelection();
      headingBox.getSelectionModel().clearSelection();
      thresholdTowardField.clear();
      thresholdAwayField.clear();
      thresholdCentreField.clear();
      obstacleHeightField.clear();
      blastProtectionField.clear();
      NotificationDisplay.notifyClear();
    });

    Label lineBreak =  new Label("-----------------------");

    //All calculated distances displayed in labels with appropriate headings
    HBox landingValues = new HBox();
    landingValues.setSpacing(10);
    VBox beforeValues = new VBox();
    Label beforeLabel = new Label("Previous Redeclare");
    beforeValues.getChildren().add(beforeLabel);
    VBox afterValues = new VBox();
    Label afterLabel = new Label("Current Redeclare");
    afterValues.getChildren().add(afterLabel);
    landingValues.getChildren().addAll( beforeValues, afterValues);

    Label ldaLabel = new Label("Landing Distance Available");
    beforeValues.getChildren().add(ldaLabel);
    Label ldaNumber = new Label();
    ldaNumber.textProperty().bind(Bindings.createStringBinding(() ->
        getRunwayValues().getLDAProperty().getValue().toString() + " m",
        getRunwayValues().getLDAProperty()));
    Label prevLDANumber = new Label();
    prevLDA= new SimpleIntegerProperty(getRunwayValues().getLDAProperty().getValue());

    prevLDANumber.textProperty().bind(Bindings.createStringBinding(() ->
            prevLDA.getValue().toString() +" m",prevLDA));
    beforeValues.getChildren().add(prevLDANumber);
    afterValues.getChildren().addAll(new Label("\n"),ldaNumber);

    Label toraLabel = new Label("Take-Off Run Available");
    beforeValues.getChildren().add(toraLabel);

    Label toraNumber = new Label();
    toraNumber.textProperty().bind(Bindings.createStringBinding(() ->
        getRunwayValues().getTORAProperty().getValue().toString() + " m",
        getRunwayValues().getTORAProperty()));
    Label prevTORANumber = new Label();
    prevTORA= new SimpleIntegerProperty(getRunwayValues().getTORAProperty().getValue());
    prevTORANumber.textProperty().bind(Bindings.createStringBinding(() ->
        prevTORA.getValue().toString() +" m",prevTORA));
    beforeValues.getChildren().add(prevTORANumber);
    afterValues.getChildren().addAll(new Label("\n"),toraNumber);

    Label asdaLabel = new Label("Accelerate-Stop Distance Available");
    beforeValues.getChildren().add(asdaLabel);

    //How to bind a number to a text point.
    Label asdaNumber = new Label();
    asdaNumber.textProperty().bind(Bindings.createStringBinding(() ->
        getRunwayValues().getASDAProperty().getValue().toString() + " m",
        getRunwayValues().getASDAProperty()));
    Label prevASDANumber = new Label();
    prevASDA= new SimpleIntegerProperty(getRunwayValues().getASDAProperty().getValue());
    prevASDANumber.textProperty().bind(Bindings.createStringBinding(() ->
        prevASDA.getValue().toString() +" m",prevASDA));
    beforeValues.getChildren().add(prevASDANumber);
    afterValues.getChildren().addAll(new Label("\n"),asdaNumber);

    Label todaLabel = new Label("Take-Off Distance Available");
    beforeValues.getChildren().add(todaLabel);

    //How to bind a number to a text point.
    Label todaNumber = new Label();
    todaNumber.textProperty().bind(Bindings.createStringBinding(() ->
        getRunwayValues().getTODAProperty().getValue().toString() + " m",
        getRunwayValues().getTODAProperty()));
    Label prevTODANumber = new Label();
    prevTODA= new SimpleIntegerProperty(getRunwayValues().getTODAProperty().getValue());
    prevTODANumber.textProperty().bind(Bindings.createStringBinding(() ->
        prevTODA.getValue().toString() +" m",prevTODA));
    beforeValues.getChildren().add(prevTODANumber);
    afterValues.getChildren().addAll(new Label("\n"),todaNumber);

    this.getChildren().add( landingValues);

    beforeValues.setTranslateX(10);
    afterValues.setTranslateX(10);

    //Delete later: plan, set property values to all parts of the label to take in old values after redeclare is pressed
  }

  /**
   * Gets runway declaration values from the app instance
   * @return RunwayDeclaration
   */
  public RunwayDeclaration getRunwayValues() {
    return App.getInstance().getRunwayDeclaration();
  }

  private int limit(int num) {
    if (num == 0) return 36;
    return num;
  }

  /**
   * Set headings
   * @param heading left heading designator
   */
  public void setHeadingOptions(int heading) {
    ObservableList<Integer> headingOptions = FXCollections
        .observableArrayList(Math.min(heading, limit((heading + 18) % 36)),
            Math.max(heading, limit((heading + 18) % 36)));
    this.getChildren().remove(headingBox);
    headingBox = new ComboBox<>(headingOptions);
    headingBox.setPromptText("Select a heading...");
    this.getChildren().add(3, headingBox);
  }
}
