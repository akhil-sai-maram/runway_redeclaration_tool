package view.scenes;

import control.App;
import java.io.File;
import java.util.HashMap;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;
import javafx.application.Platform;
import javafx.beans.binding.Bindings;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleListProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.geometry.Point2D;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.SnapshotParameters;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceDialog;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.ScrollPane.ScrollBarPolicy;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TabPane.TabClosingPolicy;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.transform.Scale;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Pair;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import utils.NotificationDisplay;
import utils.Parser;
import utils.RunwayDeclaration;
import utils.Sanitisation;
import view.BuildWindow;
import view.ToolWindow;
import view.TutorialWindow;
import view.components.InputPane;
import view.components.RunwayDesign;
import view.components.RunwayInput;
import view.components.SideOnRunway;
import view.components.TopDownRunway;


/**
 * Scene class where input is taken to determine the view
 */
public class RunwayScene extends BaseScene {

  /**
   * Relevant components to indicate the aspects of scene
   */
  private InputPane inputBox;
  private TabPane tabs;
  private final HashMap<Integer, Pair<TopDownRunway, SideOnRunway>> runwayMap = new HashMap<>();
  private int currentId = 0;


  /**
   * Boolean to indicate current view
   */
  private boolean view = true;

  /**
   * Constructor
   * @param window toolwindow for scene to be placed on
   */
  public RunwayScene(ToolWindow window) {
    super(window);
  }

  /**
   * Initialise this scene. Called after creation
   */
  @Override
  public void initialise() {

  }

  /**
   * Build the layout of the scene
   */
  @Override
  public void build() {
    tabs = new TabPane();
    tabs.setTabClosingPolicy(TabClosingPolicy.ALL_TABS);
    main.setCenter(tabs);

    SimpleIntegerProperty heading = App.getInstance().getRunwayDeclaration().headingProperty();
    SimpleStringProperty headingExt = App.getInstance().getRunwayDeclaration().headingExtensionProperty();

    //We bind the property using a property creator. In this creator, we calculate the two possible
    //runway headings by adding 18 and taking the modulus. If the number produced is 0,
    // we need to change it to be 36 done with the limit function. Once we have calculated the
    // two possible runway values,
    // we must take the min and max for the left and right respectively and then convert
    // them into strings to be parsed to the string property
    SimpleStringProperty headingLeft = new SimpleStringProperty();
    headingLeft.bind(
        Bindings.createStringBinding(
            () -> String.valueOf(Math.min(heading.getValue(),
                limit((heading.getValue() + 18) % 36))), heading));

    SimpleStringProperty headingRight = new SimpleStringProperty();
    headingRight.bind(
        Bindings.createStringBinding(
            () -> String.valueOf(Math.max(heading.getValue(),
                limit((heading.getValue() + 18) % 36))), heading));

    SimpleStringProperty leftExtension = new SimpleStringProperty();
    SimpleStringProperty rightExtension = new SimpleStringProperty();


    if (heading.getValue() < 18) {
      leftExtension.set(headingExt.getValue());
      rightExtension.set(returnOppositeExtension(headingExt.getValue()));
    } else {
      rightExtension.set(headingExt.getValue());
      leftExtension.set(returnOppositeExtension(headingExt.getValue()));
    }

    //Setup menu on top of view
    MenuBar menuBar = new MenuBar();
    Menu file = new Menu("File");
    //Add option for tutorial to be displayed, and present relevant notification
    MenuItem tutorial = new MenuItem("Tutorial");
    file.getItems().add(tutorial);
    tutorial.setOnAction(event -> {
      NotificationDisplay.notifyOpenTutorial();
      Stage tutorialStage = new Stage();
      TutorialWindow tutorialWin = new TutorialWindow();
      tutorialWin.start(tutorialStage);
    });


    //Add option to select and display different obstacles
    Menu obstacle = new Menu("Obstacles");

    MenuItem planes = new MenuItem("Planes");
    MenuItem vehicles = new MenuItem("Vehicles");
    MenuItem debris = new MenuItem("Debris");
    MenuItem importObstacle = new MenuItem("Import Obstacle");
    obstacle.getItems().addAll(planes, vehicles,debris, importObstacle);

    menuBar.getMenus().addAll(file, obstacle);
    //Set the image of the obstacle
    planes.setOnAction(event -> {
      int t = Integer.parseInt(tabs.getSelectionModel().getSelectedItem().getId());
      TopDownRunway tdRunway = runwayMap.get(t).getKey();
      SideOnRunway  sdRunway = runwayMap.get(t).getValue();
      tdRunway.changeObstacle(this.getClass().getResource("/images/SPlaneTopDown.png").toExternalForm());
      sdRunway.changeObstacle(this.getClass().getResource("/images/planeSideOn.png").toExternalForm());
    });
    vehicles.setOnAction(event -> {
      int t = Integer.parseInt(tabs.getSelectionModel().getSelectedItem().getId());
      TopDownRunway tdRunway = runwayMap.get(t).getKey();
      SideOnRunway  sdRunway = runwayMap.get(t).getValue();
      tdRunway.changeObstacle(this.getClass().getResource("/images/vehicleTopDown.png").toExternalForm());
      sdRunway.changeObstacle(this.getClass().getResource("/images/vehicleSideOn.png").toExternalForm());
    });
    debris.setOnAction(event -> {
      int t = Integer.parseInt(tabs.getSelectionModel().getSelectedItem().getId());
      TopDownRunway tdRunway = runwayMap.get(t).getKey();
      SideOnRunway  sdRunway = runwayMap.get(t).getValue();
      tdRunway.changeObstacle(this.getClass().getResource("/images/debris.png").toExternalForm());
      sdRunway.changeObstacle(this.getClass().getResource("/images/debris.png").toExternalForm());
    });
    importObstacle.setOnAction(
        event -> {
          //Open file explorer to select file
          Stage newStage = new Stage();
          FileChooser fileChooser = new FileChooser();
          File chosenFile = fileChooser.showOpenDialog(newStage);
          if (chosenFile != null) {
            int t = Integer.parseInt(tabs.getSelectionModel().getSelectedItem().getId());
            TopDownRunway tdRunway = runwayMap.get(t).getKey();
            SideOnRunway  sdRunway = runwayMap.get(t).getValue();
            if (chosenFile.getName().endsWith(".png")) {
              try {
                tdRunway.changeObstacle(chosenFile.toURI().toURL().toString());
                sdRunway.changeObstacle(chosenFile.toURI().toURL().toString());
              } catch (Exception e) {
                e.printStackTrace();
              }
            }
          }
        });


    //Add options that affect the runway view
    Menu buildRunway = new Menu("New runway");
    file.getItems().add(buildRunway);

    MenuItem buildNew = new MenuItem("Build From Scratch");
    MenuItem importRunway = new MenuItem("Import Runway");
    MenuItem predefined = new MenuItem("Predefined Runways");
    buildRunway.getItems().add(buildNew);
    buildRunway.getItems().add(importRunway);
    buildRunway.getItems().add(predefined);
    // Direct user to new window for defining runway
    buildNew.setOnAction(
        event -> {
          Stage buildStage = new Stage();
          BuildWindow buildWindow = new BuildWindow();
          RunwayDeclaration declaration = buildWindow.getDeclaration(buildStage);
          //To make sure the built runway is within specification
          try {
            Sanitisation.sanitiseDeclaration(declaration);
          } catch (Exception e) {
            NotificationDisplay.notifyNewBuild(false);
            return;
          }
          window.declare(declaration);
          Tab tab = new Tab(String.valueOf(declaration.getHeading()));
          tab.onClosedProperty().set(event1 -> runwayMap.remove(tab));
          SimpleIntegerProperty head = new SimpleIntegerProperty(declaration.getHeading());
          SimpleStringProperty headExt =
              new SimpleStringProperty(declaration.getHeadingExtension());
          tab.setContent(runwayBuilder(head, headExt, tab));
          tabs.getTabs().add(tab);

          NotificationDisplay.notifyFileBuild(String.valueOf(declaration.getHeading()));
        });
    // Direct user to file explorer to choose xml file
    importRunway.setOnAction(
        event -> {
          // Open file explorer to select file
          Stage newStage = new Stage();
          FileChooser fileChooser = new FileChooser();
          File chosenFile = fileChooser.showOpenDialog(newStage);
          if (chosenFile != null) {
            RunwayDeclaration declaration = Parser.parse(chosenFile, window);
            try {
              Sanitisation.sanitiseDeclaration(declaration);
            } catch (Exception e) {
              NotificationDisplay.notifyNewBuild(false);
              return;
            }
            window.declare(declaration);
            String chosenName = chosenFile.getName().split("\\.")[0];

            Tab tab = new Tab(chosenName);
            tab.onClosedProperty().set(event1 -> runwayMap.remove(tab));
            SimpleIntegerProperty head = new SimpleIntegerProperty(declaration.getHeading());
            SimpleStringProperty headExt = new SimpleStringProperty(declaration.getHeadingExtension());
            tab.setContent(runwayBuilder(head, headExt, tab));
            tabs.getTabs().add(tab);

            NotificationDisplay.notifyFileBuild(chosenFile.getName());
          }
        });
    //Direct user to select from predefined runways
    predefined.setOnAction(event -> {
      ObservableList<String> runwaySelector = FXCollections.observableArrayList(
          "Gatwick Runway (08L 26R): 3316 metres by 45 metres",
          "Gatwick Runway (26L 08R): 2565 metres by 45 metres",
          "Heathrow Runway (09L 27R): 3902 metres by 50 metres",
          "Heathrow Runway (27L 09R): 3658 metres by 50 metres",
          "Manchester Runway (05L 23R): 3048 metres by 46 metres",
          "Manchester Runway (23L 05R): 3200 metres by 60 metres");

      //Pop up notification to choose runway configuration
      ChoiceDialog<String> options = new ChoiceDialog<>("Runway Configuration", runwaySelector);
      options.setTitle("Runway Selector");
      options.setHeaderText("Select a runway from below");
      Optional<String> selection = options.showAndWait();
      selection.ifPresent(runway -> {
        String[] info = runway.split(":")[0].split(" ");
        info[0] = "";
        String r = String.join(" ",info).replace(" (",":").replace(")","");
        RunwayDeclaration declaration = RunwayInput.existingDeclaration(runway);
        if (declaration == null) {
          return;
        }
        try {
          Sanitisation.sanitiseDeclaration(declaration);
        } catch (Exception e) {
          NotificationDisplay.notifyNewBuild(false);
          return;
        }
        window.declare(declaration);
        Tab tab = new Tab(String.valueOf(declaration.getHeading()));
        tab.onClosedProperty().set(event1 -> runwayMap.remove(tab));
        SimpleIntegerProperty head = new SimpleIntegerProperty(declaration.getHeading());
        SimpleStringProperty headExt = new SimpleStringProperty(declaration.getHeadingExtension());
        tab.setContent(runwayBuilder(head, headExt, tab));
        tabs.getTabs().add(tab);

        NotificationDisplay.notifyFileBuild(String.valueOf(declaration.getHeading()));
      });

    });

    //Add option for user to export current runway information
    MenuItem export = new MenuItem("Export current runway");
    file.getItems().add(export);
    export.setOnAction(event -> {
      TextInputDialog dialog = new TextInputDialog("Enter name of runway");
      dialog.setHeaderText("What would you like to save the runway as?");
      dialog.show();
      dialog.setOnCloseRequest(event2 -> {
        try {
          Parser.writeDeclaration(inputBox.getRunwayValues(), dialog.getEditor().getText());
        } catch (ParserConfigurationException | TransformerException e) {
          e.printStackTrace();
        }
      });
    });

    MenuItem imageRunway = new MenuItem("Export runway view");
    file.getItems().add(imageRunway);
    imageRunway.setOnAction(event -> {
      int t = Integer.parseInt(tabs.getSelectionModel().getSelectedItem().getId());

      WritableImage writableImage = runwayMap.get(t).getKey().getPane().
          snapshot(new SnapshotParameters(), null);
      ImageView imageView = new ImageView(writableImage);

      WritableImage writableImage1 = runwayMap.get(t).getValue().getPane().
          snapshot(new SnapshotParameters(), null);
      ImageView imageView1 = new ImageView(writableImage1);

      HBox imageContent = new HBox(50,imageView,imageView1);
      imageContent.getChildren().forEach(e -> e.setStyle("-fx-border-color: grey; -fx-border-width: 1px;"));
      imageContent.setAlignment(Pos.CENTER);

      Button resize = new Button("Adjust zoom property:");
      TextField inputResize = new TextField();
      HBox inputUser = new HBox(resize,inputResize);
      inputUser.setAlignment(Pos.BOTTOM_CENTER);

      Button tdVisible = new Button("Top Down View");
      Button soVisible = new Button("Side On View");
      HBox viewOptions = new HBox(50,tdVisible,soVisible);
      viewOptions.setAlignment(Pos.TOP_CENTER);

      tdVisible.setOnAction(e -> {
        imageView.setVisible(!imageView.isVisible());
      });

      soVisible.setOnAction(e -> {
        imageView1.setVisible(!imageView1.isVisible());
      });

      inputResize.textProperty().addListener((observable, oldValue, newValue) -> {
        if (!newValue.matches("\\d*\\.?\\d*")) {
          inputResize.setText(newValue.replaceAll("[^\\d\\.]", ""));
        }
      });

      // Add the ImageView to ScrollPane
      ScrollPane scrollPane = new ScrollPane(imageContent);
      //scrollPane.setPannable(true);
      scrollPane.setFitToHeight(true);
      scrollPane.setFitToWidth(true);
      scrollPane.setHbarPolicy(ScrollBarPolicy.AS_NEEDED);
      scrollPane.setVbarPolicy(ScrollBarPolicy.AS_NEEDED);

      // Add a Scale transform to the StackPane
      BorderPane viewPane = new BorderPane(scrollPane);
      viewPane.setBottom(inputUser);
      viewPane.setTop(viewOptions);
      Scale scale = new Scale(1, 1);
      viewPane.getTransforms().add(scale);

      AtomicReference<Double> zoomval = new AtomicReference<>(2.0);
      resize.setOnAction(e -> zoomval.set(Double.valueOf(inputResize.getText())));

      // Add a zoom event handler to the StackPane to allow for zooming
      viewPane.setOnMouseClicked(event1 -> {
        if (event1.getClickCount() == 2) {

          // Zoom in or out based on the current scale
          if (scale.getX() == 1 && scale.getY() == 1) {
            // Zoom in
            Point2D mousePosition = viewPane.screenToLocal(event1.getScreenX(), event1.getScreenY());
            scale.setPivotX(mousePosition.getX());
            scale.setPivotY(mousePosition.getY());

            scale.setX(zoomval.get());
            scale.setY(zoomval.get());
          } else {
            // Zoom out
            scale.setX(1);
            scale.setY(1);
          }
          event1.consume();
        }
      });

      Scene scene = new Scene(viewPane, 900, 700);

      Stage stage = new Stage();
      stage.setScene(scene);

      stage.show();
    });


    main.setTop(menuBar);

    //Portion of UI responsible for gathering data
    inputBox = new InputPane(window,this);
    main.setLeft(inputBox);

    Tab exampleTab = new Tab("Example");
    exampleTab.closableProperty().set(false);
    BorderPane runways = runwayBuilder(heading, headingExt, exampleTab);
    exampleTab.setContent(runways);

    //Add history tab to view recent actions
    Menu notificationMenu = new Menu("History");
    menuBar.getMenus().add(notificationMenu);

    var notificationsList = NotificationDisplay.getHistory();
    SimpleListProperty<String> notificationsSLP = new SimpleListProperty<>(notificationsList);

    //Add listener to detect incoming actions and display them
    notificationsSLP.addListener(
        (ListChangeListener<? super String>) s -> {
          MenuItem temp = new MenuItem(NotificationDisplay.update(s.toString()));
          //Wait for updated list and add new item to history tab
          Platform.runLater(() -> notificationMenu.getItems().add(temp));
        }
    );


    exampleTab.setId("0");

    tabs.getTabs().add(exampleTab);
  }

  /**
   * Build a pane with all the functionality required of a runway view
   * @param head the heading of the declaration
   * @param headExtension the extension of the declaration
   * @param tab the tab the runway view will be placed in
   * @return a pane containing a runway view
   */
  private BorderPane runwayBuilder(SimpleIntegerProperty head, SimpleStringProperty headExtension, Tab tab) {
    BorderPane pane = new BorderPane();

    SimpleStringProperty left = new SimpleStringProperty();
    left.bind(
        Bindings.createStringBinding(
            () -> String.valueOf(Math.min(head.getValue(),
                limit((head.getValue() + 18) % 36))), head));
    SimpleStringProperty right = new SimpleStringProperty();
    right.bind(
        Bindings.createStringBinding(
            () -> String.valueOf(Math.max(head.getValue(),
                limit((head.getValue() + 18) % 36))), head));

    SimpleStringProperty rightExt = new SimpleStringProperty();
    SimpleStringProperty leftExt = new SimpleStringProperty();

    if (head.getValue() < 18) {
      leftExt.set(headExtension.getValue());
      rightExt.set(returnOppositeExtension(headExtension.getValue()));
    } else {
      rightExt.set(headExtension.getValue());
      leftExt.set(returnOppositeExtension(headExtension.getValue()));
    }

    TopDownRunway topDownRunway = new TopDownRunway(250f,40f, left, right, leftExt, rightExt);
    topDownRunway.build();
    SideOnRunway sideOnRunway = new SideOnRunway(250f, left, right, leftExt, rightExt);
    sideOnRunway.build();

    //Switch between different views from button click, and notify new runway presented
    Button changeViewButton = new Button("Change View");
    changeViewButton.setOnAction(event -> {
      if (view) {
        pane.setCenter(runwayMap.get(Integer.parseInt(tab.getId())).getValue().getPane());
        view = false;
        NotificationDisplay.notifyViewChange(view);
      } else {
        pane.setCenter(runwayMap.get(Integer.parseInt(tab.getId())).getKey().getPane());
        view = true;
        NotificationDisplay.notifyViewChange(view);
      }
    });

    //HBox to contain relevant nodes for rotating top down view
    HBox rotationBox = new HBox();
    Button rotationButton = new Button("Rotate");
    rotationBox.getChildren().addAll(rotationButton);

    topDownRunway.getPane().add(rotationBox,4,10,10,9);

    //Rotate view and present notifications
    rotationButton.setOnAction(event -> {
      if (!view) {
        return;
      }
      topDownRunway.rotate();
      NotificationDisplay.notifyViewRotation();
    });

    HBox bottombar = new HBox(window.getWidth()/3);
    //Add hbox to bottom of view and translate to appropriate position on scene
    bottombar.getChildren().addAll(changeViewButton, rotationBox);
    pane.setBottom(bottombar);
    bottombar.setTranslateX(20);
    bottombar.setTranslateY(-10);

    Pair<TopDownRunway, SideOnRunway> pair = new Pair<>(topDownRunway, sideOnRunway);
    tab.setId(String.valueOf(currentId));
    runwayMap.put(currentId, pair);
    tab.setOnSelectionChanged(
        event -> {
          App.getInstance().setRunwayDeclaration(Integer.parseInt(tab.getId()));
          inputBox.setHeadingOptions(App.getInstance().getRunwayDeclaration().getHeading());
          view = true;
          pane.setCenter(topDownRunway.getPane());
        });
    currentId++;
    pane.setCenter(topDownRunway.getPane());
    return pane;
  }

  private String returnOppositeExtension(String extension) {
    if (Objects.equals(extension, "L")) {
      return "R";
    } else {
      return "L";
    }
  }

  /**
   * Get the currently selected tab
   * @return currently selected tab
   */
  public int getSelectedTab() {
    return Integer.parseInt(tabs.getSelectionModel().getSelectedItem().getId());
  }

  @Override
  public int getCurrentID() {
    return currentId;
  }

  /**
   * Get the relevant runway object
   * @return runway
   */
  public RunwayDesign getRunway() {
    if (view) { return runwayMap.get(Integer.parseInt(tabs.getSelectionModel().getSelectedItem().getId())).getKey();}
    else {return runwayMap.get(Integer.parseInt(tabs.getSelectionModel().getSelectedItem().getId())).getValue();}
  }

  /**
   * Ensure that lowest heading is 1
   * @param num heading number
   * @return modified number
   */
  private int limit(int num) {
    if (num == 0) return 36;
    return num;
  }


  /**
   * Add heading to inputBox
   * @param heading heading to add
   */
  public void setHeadingOptions(int heading) {
    inputBox.setHeadingOptions(heading);
  }

}
