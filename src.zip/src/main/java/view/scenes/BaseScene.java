package view.scenes;

import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.BorderPane;
import view.ToolWindow;
import view.components.RunwayDesign;

/**
 * BaseScene to be extended by other scenes
 */
public abstract class BaseScene {

  /**
   * Window that holds the scene
   */
  protected final ToolWindow window;

  /**
   * Current scene
   */
  protected Scene scene;

  /**
   * Borderpane to be added to current scene
   */
  protected BorderPane main = new BorderPane();

  /**
   * Constructor
   * @param toolWindow window for scene to be placed on
   */
  public BaseScene(ToolWindow toolWindow) {
    this.window = toolWindow;
  }

  /**
   * Initialise this scene. Called after creation
   */
  public abstract void initialise();

  /**
   * Build the layout of the scene
   */
  public abstract void build();

  /**
   * Create a new JavaFX scene using the root contained within this scene
   * @return JavaFX scene
   */
  public Scene setScene() {
    var previous = window.getScene();
    Scene scene = new Scene(main, previous.getWidth(), previous.getHeight());
    try {
      scene.getStylesheets().add(getClass().getResource("/style/runwaytool.css").toExternalForm());
    } catch (Exception e) {
      Alert alert = new Alert(AlertType.ERROR, "An error has occurred. Unable to retrieve CSS file.");
      alert.setTitle("An Error Has Occurred");
    }
    this.scene = scene;
    return scene;
  }

  /**
   * Get the JavaFX scene contained inside
   * @return JavaFX scene
   */
  public Scene getScene() {
    return this.scene;
  }

  /**
   * Get current active tab
   * @return selected tab
   */
  public abstract int getSelectedTab();

  /**
   * Get ID of current active tab
   * @return ID of active tab
   */
  public abstract int getCurrentID();

  /**
   * Get runway object
   * @return runway
   */
  public abstract RunwayDesign getRunway();

  /**
   * Set the heading
   * @param heading primary heading to set
   */
  public abstract void setHeadingOptions(int heading);

}
