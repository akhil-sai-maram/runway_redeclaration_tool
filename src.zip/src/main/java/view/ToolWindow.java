package view;

import control.App;
import java.util.ArrayList;
import java.util.List;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import listeners.DeclarationListener;
import model.RunwayModel.DeclarationType;
import utils.ObstacleDeclaration;
import utils.RunwayDeclaration;
import view.scenes.BaseScene;
import view.scenes.RunwayScene;

/**
 * Window for displaying the runwayScene
 */
public class ToolWindow {

  /**
   * width and height of stage
   */
  private final int width;
  private final int height;

  /**
   * Listeners for declaration change
   */
  private final List<DeclarationListener> listeners = new ArrayList<>();

  /**
   * Stage
   */
  private final Stage stage;

  /**
   * BaseScene object
   */
  private BaseScene currentScene;

  /**
   * Scene object
   */
  public Scene scene;

  /**
   * Constructor
   * @param stage primary stage
   * @param width width
   * @param height height
   */
  public ToolWindow(Stage stage, int width, int height) {
    this.width = width;
    this.height = height;

    this.stage = stage;

    //Setup window
    setupStage();

    //sets a basic scene to change to
    setupDefaultScene();

    //Setup start scene with TopDown scene
    startRunway();
  }

  /**
   * Setup the default settings for the stage itself (the window), such as the title and minimum width and height.
   */
  public void setupStage() {
    stage.setTitle("Runway Re-Declaration");
    stage.setMinWidth(width);
    stage.setMinHeight(height + 20);
    stage.setOnCloseRequest(ev -> App.getInstance().shutdown());
  }

  /**
   * Load a given scene which extends BaseScene and switch over.
   * @param newScene new scene to load
   */
  public void loadScene(BaseScene newScene) {
    //Create the new scene and set it up
    newScene.build();
    currentScene = newScene;
    scene = newScene.setScene();
    stage.setScene(scene);

    //Initialise the scene when ready
    Platform.runLater(() -> currentScene.initialise());
  }

  /**
   * load the RunwayScene
   */
  public void startRunway() {loadScene(new RunwayScene(this));}

  /**
   * Accessor method for scene
   * @return
   */
  public Scene getScene() {
    return scene;
  }

  /**
   * Setup the default scene (an empty black scene) when no scene is loaded
   */
  public void setupDefaultScene() {
    this.scene = new Scene(new Pane(),width,height, Color.BLACK);
    stage.setScene(this.scene);
  }

  /**
   * Get the width of the Game Window
   * @return width
   */
  public int getWidth() {
    return this.width;
  }

  /**
   * Get the height of the Game Window
   * @return height
   */
  public int getHeight() {
    return this.height;
  }

  /**
   * Accessor method for active tab
   * @return current tab
   */
  public int getSelectedTab() {
    return currentScene.getSelectedTab();
  }

  /**
   * Accessor method to get ID of active tab
   * @return ID of current tab
   */
  public int getCurrentID() {
    return currentScene.getCurrentID();
  }

  /**
   * Add listener to declaration listeners
   * @param listener
   */
  public void addListener(DeclarationListener listener) {
    listeners.add(listener);
  }

  /**
   * Alert all the listeners to a new declaration
   * @param declaration the new declaration
   */
  public void declare(RunwayDeclaration declaration) {
    for (DeclarationListener l : listeners) {
      l.declare(declaration);
    }
    currentScene.setHeadingOptions(declaration.getHeading());
  }

  /**
   * Alert all the listeners to a redeclaration
   * @param declaration the obstacle declaration
   * @param declarationType the type of redeclaration
   * @param blastProtection the distance behind a plane to stop it damaging objects behind it
   * @throws Exception if the redeclaration fails
   */
  public void redeclare(ObstacleDeclaration declaration, DeclarationType declarationType, int blastProtection) throws Exception {
    for (DeclarationListener l : listeners) {
      l.redeclare(declaration, declarationType, blastProtection);
    }
  }

  /**
   * Error message for invalid LDA
   */
  public void errorLDA() {
    Alert alert = new Alert(AlertType.WARNING, "Incorrect LDA specified", ButtonType.OK);
    alert.showAndWait();
  }

  /**
   * Error message for invalid TORA
   */
  public void errorTORA() {
    Alert alert = new Alert(AlertType.WARNING, "Incorrect TORA specified", ButtonType.OK);
    alert.showAndWait();
  }

  /**
   * Error message for invalid ASDA
   */
  public void errorASDA() {
    Alert alert = new Alert(AlertType.WARNING, "Incorrect ASDA specified", ButtonType.OK);
    alert.showAndWait();
  }

  /**
   * Error message for invalid TODA
   */
  public void errorTODA() {
    Alert alert = new Alert(AlertType.WARNING, "Incorrect TODA specified", ButtonType.OK);
    alert.showAndWait();
  }

  /**
   * Error message for invalid threshold
   */
  public void errorThreshold() {
    Alert alert = new Alert(AlertType.WARNING, "Incorrect threshold specified", ButtonType.OK);
    alert.showAndWait();
  }

  /**
   * Error message for invalid centre
   */
  public void errorCentre() {
    Alert alert = new Alert(AlertType.WARNING, "Incorrect centre offset specified", ButtonType.OK);
    alert.showAndWait();
  }

  /**
   * Error message for invalid height
   */
  public void errorHeight() {
    Alert alert = new Alert(AlertType.WARNING, "Incorrect obstacle height specified", ButtonType.OK);
    alert.showAndWait();
  }

  /**
   * Error message for invalid heading
   */
  public void errorHeading() {
    Alert alert = new Alert(AlertType.WARNING, "Incorrect heading specified", ButtonType.OK);
    alert.showAndWait();
  }

  /**
   * Error message for invalid blast protection
   */
  public void errorBP() {
    Alert alert = new Alert(AlertType.WARNING, "Incorrect blast protection specified", ButtonType.OK);
    alert.showAndWait();
  }
}

