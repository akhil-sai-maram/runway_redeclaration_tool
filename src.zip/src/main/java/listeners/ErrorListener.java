package listeners;

/**
 * Used to make the App class a listener for errors
 */
public interface ErrorListener {

  /**
   * Error for invalid LDA
   */
  void errorLDA();

  /**
   * Error for invalid TORA
   */
  void errorTORA();

  /**
   * Error for invalid ASDA
   */
  void errorASDA();

  /**
   * Error for invalid TODA
   */
  void errorTODA();

  /**
   * Error for invalid threshold
   */
  void errorThreshold();

  /**
   * Error for invalid centre
   */
  void errorCentre();

  /**
   * Error for invalid height
   */
  void errorHeight();

  /**
   * Error for invalid blast protection
   */
  void errorBP();

  /**
   * Error for invalid heading
   */
  void errorHeading();
}
