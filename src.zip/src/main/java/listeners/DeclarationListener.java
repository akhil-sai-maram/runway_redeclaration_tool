package listeners;

import model.RunwayModel.DeclarationType;
import utils.ObstacleDeclaration;
import utils.RunwayDeclaration;

/**
 * Used to make the App class a listener for declarations
 */
public interface DeclarationListener {

  /**
   * Redeclare the currently selected runway
   * @param declaration the declaration of the obstacle
   * @param declarationType mode that user selects
   * @param blastProtection the blast protection
   * @throws Exception when a redeclare is given an invalid declaration or
   * would produce an invalid declaration
   */
  void redeclare(ObstacleDeclaration declaration, DeclarationType declarationType, int blastProtection) throws Exception;

  /**
   * Adds a new runway declaration for use
   * @param declaration the declaration of the new runway
   */
  void declare(RunwayDeclaration declaration);
}
