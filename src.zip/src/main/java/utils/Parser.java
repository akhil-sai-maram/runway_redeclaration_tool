package utils;

import java.io.File;
import java.nio.file.Files;
import javafx.application.Platform;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import view.ToolWindow;

/**
 * Utility class for file handling
 */
public class Parser {

  /**
   * Parse an XML runway declaration
   * @param file a file that contains an XML declaration of a runway
   * @param toolWindow tool window
   * @return a completed runway declaration
   */
  public static RunwayDeclaration parse(File file, ToolWindow toolWindow) {
    RunwayDeclaration declaration = new RunwayDeclaration();

    //Handle cases where file is not a xml file
    try {
      String fileType = Files.probeContentType(file.toPath()).split("/")[1];
      if (!fileType.equals("xml")) throw new Exception("Incorrect file format");
    } catch (Exception e) {
      e.printStackTrace();
    }

    try {
      //Extract information stored in file
      DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
      DocumentBuilder builder = factory.newDocumentBuilder();
      Document document = builder.parse(file);
      document.getDocumentElement().normalize();

      //Extract content stored in the appropriate xml tags
      int lda = Integer.parseInt(document.getElementsByTagName("lda").item(0).getTextContent());
      int tora = Integer.parseInt(document.getElementsByTagName("tora").item(0).getTextContent());
      int asda = Integer.parseInt(document.getElementsByTagName("asda").item(0).getTextContent());
      int toda = Integer.parseInt(document.getElementsByTagName("toda").item(0).getTextContent());
      String heading = document.getElementsByTagName("runway").item(0)
          .getAttributes().item(0).getTextContent();
      int headingNum = Integer.parseInt(heading.substring(0,2));
      String headingExt = heading.substring(2);

      //Handle errors
      if (lda == 0) {
        toolWindow.errorLDA();
        return declaration;
      } else if (tora == 0) {
        toolWindow.errorTORA();
        return declaration;
      } else if (asda == 0) {
        toolWindow.errorASDA();
        return declaration;
      } else if (toda == 0) {
        toolWindow.errorTODA();
        return declaration;
      }

      //Update RunwayDeclaration with values from document
      declaration.setLDA(lda);
      declaration.setTORA(tora);
      declaration.setASDA(asda);
      declaration.setTODA(toda);
      declaration.setHeading(headingNum);
      declaration.setHeadingExtension(headingExt);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return declaration;
  }

  /**
   * File writer to interpret and save declaration as a xml file
   * @param declaration Runway information
   * @param filename Name of file
   * @throws ParserConfigurationException paring error
   * @throws TransformerException transforming error
   */
  public static void writeDeclaration(RunwayDeclaration declaration, String filename)
      throws ParserConfigurationException, TransformerException {
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    DocumentBuilder builder = factory.newDocumentBuilder();

    //Add tags according to xml schema
    Document document = builder.newDocument();
    //root tag
    Element root = document.createElement("declaration");
    document.appendChild(root);

    //declaration tag's child node
    Element runway = document.createElement("runway");
    root.appendChild(runway);
    runway.setAttribute("heading",Integer.toString(declaration.getHeading()));

    //lda,asda,tora,toda are all runway tag's child nodes

    //Get values from declaration and store them in appropriate xml tag
    Element lda = document.createElement("lda");
    lda.appendChild(document.createTextNode(Integer.toString(declaration.getLDA())));
    runway.appendChild(lda);

    Element tora = document.createElement("tora");
    tora.appendChild(document.createTextNode(Integer.toString(declaration.getTORA())));
    runway.appendChild(tora);

    Element asda = document.createElement("asda");
    asda.appendChild(document.createTextNode(Integer.toString(declaration.getASDA())));
    runway.appendChild(asda);

    Element toda = document.createElement("toda");
    toda.appendChild(document.createTextNode(Integer.toString(declaration.getTODA())));
    runway.appendChild(toda);

    //Open file explorer to allow user to select directory to add file
    DirectoryChooser chooser = new DirectoryChooser();
    chooser.setTitle("Select a folder to store the runway information");

    Stage fileStage = new Stage();
    File file = chooser.showDialog(fileStage);

    if (file != null) {
      //Use the filename to create the xml file to store in required directory
      String path = file.getAbsolutePath() + File.separator + filename + ".xml";
      File output = new File(path);
      DOMSource dom = new DOMSource(document);
      Transformer transformer = TransformerFactory.newInstance().newTransformer();
      //Pretty print xml document
      transformer.setOutputProperty(OutputKeys.INDENT, "yes");
      transformer.transform(dom,new StreamResult(output));
      //Display notification
      Platform.runLater(() -> NotificationDisplay.notifyExportFile(filename));
    } else {
      //Display warning if a directory is not chosen
      Alert update = new Alert(AlertType.WARNING);
      update.setTitle("Warning");
      update.setContentText("Invalid directory to store file");
      update.show();
    }

  }
}
