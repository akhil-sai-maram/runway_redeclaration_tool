package utils;

/**
 * Declare parameters of obstacle placement
 */
public class ObstacleDeclaration {

  /**
   * Thresholds of the obstacle
   */
  private final int thresholdToward;
  private final int thresholdAway;
  private final int thresholdCentre;
  private final int height;

  /**
   * Heading of runway
   */
  private final int heading;

  /**
   * Constructor
   * @param thresholdToward threshold toward
   * @param thresholdAway threshold away
   * @param thresholdCentre threshold centre
   * @param height height
   * @param heading heading
   */
  public ObstacleDeclaration(int thresholdToward, int thresholdAway, int thresholdCentre,
      int height, int heading) {
    this.thresholdToward = thresholdToward;
    this.thresholdAway = thresholdAway;
    this.thresholdCentre = thresholdCentre;
    this.height = height;
    this.heading = heading;
  }

  /**
   * Get the threshold toward
   * @return relevant threshold
   */
  public int getThresholdToward() {
    return thresholdToward;
  }

  /**
   * Get the threshold away
   * @return relevant threshold
   */
  public int getThresholdAway() {
    return thresholdAway;
  }

  /**
   * Get the threshold centre
   * @return relevant threshold
   */
  public int getThresholdCentre() {
    return thresholdCentre;
  }

  /**
   * Get height of obstacle
   * @return height
   */
  public int getHeight() {
    return height;
  }

  /**
   * Get runway heading
   * @return heading
   */
  public int getHeading() {
    return heading;
  }
}
