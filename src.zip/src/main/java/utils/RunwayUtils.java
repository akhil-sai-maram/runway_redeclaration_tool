package utils;

/**
 * Utility class for runway calculations
 */
public class RunwayUtils {

  /**
   * Slope factor
   */
  private static final int SLOPE_FACTOR = 50;

  /**
   * Strip end
   */
  private static final int STRIP_END = 60;

  /**
   * RESA
   */
  private static final int RESA = 240;

  /**
   * Calculate the re-declaration for landing over an obstacle
   * @param runwayDeclaration the declaration of the runway
   * @param obstacleDeclaration the declaration of the obstacle
   */
  public static void landingOver(
      RunwayDeclaration runwayDeclaration, ObstacleDeclaration obstacleDeclaration) {
    int obstacleObstruction =
        obstacleDeclaration.getThresholdToward()
            + Math.max(
                (obstacleDeclaration.getHeight() * SLOPE_FACTOR),
                obstacleDeclaration.getThresholdToward());
    int totalObstruction = (Math.max(obstacleObstruction, RESA
        + runwayDeclaration.getLDA() - obstacleDeclaration.getThresholdAway()) + STRIP_END);
    runwayDeclaration.setLDA(runwayDeclaration.getLDA() - totalObstruction);
  }

  /**
   * Calculate the re-declaration for landing toward an obstacle
   * @param runwayDeclaration the declaration of the runway
   * @param obstacleDeclaration the declaration of the obstacle
   */
  public static void landingToward(
      RunwayDeclaration runwayDeclaration, ObstacleDeclaration obstacleDeclaration) {
    runwayDeclaration.setLDA(obstacleDeclaration.getThresholdToward() - RESA - STRIP_END);
  }

  /**
   * Calculate the re-declaration for taking off over an obstacle
   * @param runwayDeclaration the declaration of the runway
   * @param obstacleDeclaration the declaration of the obstacle
   */
  public static void takeoffOver(RunwayDeclaration runwayDeclaration, ObstacleDeclaration obstacleDeclaration) {
    int obstacleLength = runwayDeclaration.getLDA() - obstacleDeclaration.getThresholdToward()
        - obstacleDeclaration.getThresholdAway();
    int obstacleObstruction = Math.max((obstacleDeclaration.getHeight() * SLOPE_FACTOR), obstacleLength);
    int totalObstruction = Math.max(obstacleObstruction + STRIP_END, RESA + obstacleLength +
        obstacleDeclaration.getThresholdAway() + STRIP_END);
    runwayDeclaration.setTORA(obstacleDeclaration.getThresholdToward() - totalObstruction);
    runwayDeclaration.setASDA(obstacleDeclaration.getThresholdToward() - totalObstruction);
    runwayDeclaration.setTODA(obstacleDeclaration.getThresholdToward() - totalObstruction);
  }

  /**
   * Calculate the re-declaration for taking off away from an obstacle
   * @param runwayDeclaration the declaration of the runway
   * @param obstacleDeclaration the declaration of the obstacle
   * @param blastProtectionAllowance the blast protection the plane requires
   */
  public static void takeoffAway(RunwayDeclaration runwayDeclaration, ObstacleDeclaration obstacleDeclaration, int blastProtectionAllowance) {
    int obstacleObstruction =
        ((runwayDeclaration.getLDA() - obstacleDeclaration.getThresholdToward())
            + blastProtectionAllowance);
    runwayDeclaration.setTORA(runwayDeclaration.getTORA() - obstacleObstruction);
    runwayDeclaration.setASDA(runwayDeclaration.getASDA() - obstacleObstruction);
    runwayDeclaration.setTODA(runwayDeclaration.getTODA() - obstacleObstruction);
  }
}
