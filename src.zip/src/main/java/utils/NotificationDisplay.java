package utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import org.controlsfx.control.Notifications;

/**
 * Utility class to enable appropriate notifications for actions in the software and OS
 */
public class NotificationDisplay {

  /**
   * ObservableList to store notifications in order of execution
   */
  static ObservableList<String> history = FXCollections.observableArrayList();

  /**
   * Get the exact time formatted to contain hours, minutes, and seconds
   * @param date the exact time
   * @return formatted time as string
   */
  public static String accessTime(Date date) {
    SimpleDateFormat dateFormat = new SimpleDateFormat("kk:mm:ss");
    return dateFormat.format(date);
  }

  /**
   * Notification method for declaration
   */
  public static void notifyDeclaration() {
    String time = accessTime(new Date());
    String message = "The view was successfully updated with declaration";
    String notification = "[" + time + "]: " + message;

    Notifications.create().title("Declaration Update").text(message).showConfirm();
    history.add(notification);
  }

  /**
   * Accessor method
   * @return observable list of notifications
   */
  public static ObservableList<String> getHistory() {
    return history;
  }

  /**
   * Notification method when view is cleared
   */
  public static void notifyClear() {
    String time = accessTime(new Date());
    String message = "The view was successfully cleared";
    String notification = "[" + time + "]: " + message;

    Notifications.create().title("Reset").text(message).showConfirm();
    history.add(notification);
  }

  /**
   * Notification method for switching between view
   * @param topdown the view type before switching view
   */
  public static void notifyViewChange(Boolean topdown) {
    String time = accessTime(new Date());
    String message = (topdown) ? "Now displaying top down view" : "Now displaying side on view";
    String notification = "[" + time + "]: " + message;

    Notifications.create().title("View change").text(message).showConfirm();
    history.add(notification);
  }

  /**
   * Notification method for matching view with compass
   */
  public static void notifyViewRotation() {
    String time = accessTime(new Date());
    String message = "The top down view was rotated";
    String notification = "[" + time + "]: " + message;

    Notifications.create().title("View Rotation").text(message).showConfirm();
    history.add(notification);
  }

  /**
   * Notification method for successful build using imported file
   * @param filename xml file with runway declaration
   */
  public static void notifyFileBuild(String filename) {
    String time = accessTime(new Date());
    String message = "Imported runway declaration contained in " + filename;
    String notification = "[" + time + "]: " + message;

    Notifications.create().title("File import").text(message).showConfirm();
    history.add(notification);
  }

  /**
   * Notification method for successful build from scratch
   * @param success indicate successful build
   */
  public static void notifyNewBuild(Boolean success) {
    String time = accessTime(new Date());
    String message = success ? "Runway declaration generated from scratch" :
        "Unexpected error occurred when generating new runway";
    String notification = "[" + time + "]: " + message;

    Notifications.create().title("Build success").text(message).showConfirm();
    history.add(notification);
  }

  /**
   * Notification method for successful build from existing configurations
   * @param runwayname the runway selected
   */
  public static void notifyExistingBuild(String runwayname) {
    String time = accessTime(new Date());
    String message = "Imported existing runway attributes from " + runwayname;

    if (runwayname.equals("Runway Configuration")) message = "Runway configuration not selected";

    String notification = "[" + time + "]: " + message;

    Notifications.create().title("Runway view update").text(message).showConfirm();
    history.add(notification);
  }

  /**
   * Notification method for exporting runway declaration to xml file
   * @param filename name of xml file
   */
  public static void notifyExportFile(String filename) {
    String time = accessTime(new Date());
    String message = "Successfully exported runway declaration to " + filename + ".xml";
    String notification = "[" + time + "]: " + message;

    Notifications.create().title("File export").text(message).showConfirm();
    history.add(notification);
  }

  /**
   * Notification method for opening tutorial
   */
  public static void notifyOpenTutorial() {
    String time = accessTime(new Date());
    String message = "Tutorial successfully accessed";

    String notification = "[" + time + "]: " + message;

    Notifications.create().title("Tutorial access").text(message).showConfirm();
    history.add(notification);
  }

  /**
   * Notification method for handling incorrect declaration values
   */
  public static void notifyOutOfBoundValues() {
    String time = accessTime(new Date());
    String message = "One or more declared distances are out of range";

    String notification = "[" + time + "]: " + message;

    Notifications.create().title("Declaration Error").text(message).showConfirm();
    history.add(notification);
  }

  /**
   * Reformat message to avoid content added by observable list
   * @param message message to trim
   * @return concise notification message
   */
  public static String update(String message) {
    int l = message.length();
    return message.substring(3,l-14);
  }

}
