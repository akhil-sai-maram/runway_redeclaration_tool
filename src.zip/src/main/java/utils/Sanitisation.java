package utils;

import exceptions.ASDAException;
import exceptions.BPException;
import exceptions.CentreException;
import exceptions.FormatException;
import exceptions.HeadingException;
import exceptions.HeightException;
import exceptions.TODAException;
import exceptions.TORAException;
import exceptions.ThresholdException;

/**
 * Utility class to handle sanitising declarations
 */
public class Sanitisation {

  /**
   * Max height of obstacle
   */
    private static final int OBSTACLE_MAX_HEIGHT = 30;

  /**
   * Min runway length
   */
  private static final int MIN_RUNWAY_LENGTH = 1800;

  /**
   * Max runway length
   */
  private static final int MAX_RUNWAY_LENGTH = 13000;

  /*
   * 1. TORA. This is the length of runway available and suitable for the ground run
   * of an aeroplane taking-off;
   * 2. ASDA. This is the length of TORA plus the length of any associated stopway;
   * - TORA <= ASDA <= TODA
   * 3. TODA. This is the length of TORA plus the length of any associated clearway;
   * - clearway subject to an overall limit of 50% of the TORA, minimum 60m
   * 4. LDA. This is the length of runway available and suitable for the ground landing
   * run of an aeroplane.
   * */

  /**
   * Checks is a runway declaration is well-defined.
   * If it is not then an exception is thrown according to which parameter is incorrect
   * @param dec the runway declaration to check
   * @throws FormatException specifies which parameter is incorrect
   */
  public static void sanitiseDeclaration(RunwayDeclaration dec) throws FormatException {
    //Check for invalid values and send notification before proceeding with more indepth checks
    boolean display = false;
    for (int d: dec.getDistanceVals()) {
      if (Math.min(d, MAX_RUNWAY_LENGTH) < MIN_RUNWAY_LENGTH) {
        display = true;
        break;
      }
    }

    if (display) {NotificationDisplay.notifyOutOfBoundValues();}

      if (dec.getLDA() > MAX_RUNWAY_LENGTH) throw new ThresholdException();
      if (dec.getTORA() > MAX_RUNWAY_LENGTH) throw new TORAException();
      if (dec.getTODA() > MAX_RUNWAY_LENGTH) throw new TODAException();
      if (dec.getASDA() > MAX_RUNWAY_LENGTH) throw new ASDAException();
        if (dec.getHeading() < 0 || dec.getHeading() > 36) throw new HeadingException();
        if (dec.getTORA() < MIN_RUNWAY_LENGTH) throw new TORAException();
        if (dec.getASDA() < dec.getTORA()) throw new ASDAException();
        if (dec.getTODA() < dec.getASDA()
            || dec.getTORA() * 1.5 < dec.getTODA()) throw new TODAException();
    }

  /**
   * Checks if a redeclaration is well-defined
   * @param dec the runway declaration to check
   * @throws FormatException if the declaration is not within acceptable ranges
   */
  public static void sanitiseRedeclaration(RunwayDeclaration dec) throws FormatException {
    if (dec.getLDA() < 0 || dec.getTORA() < 0
        || dec.getASDA() < 0 || dec.getTODA() < 0) throw new FormatException();
  }

  /**
   * Checks if an obstacle declaration is well-defined.
   * If it is not then an exception is thrown according to which parameter is incorrect.
   * @param runwayDeclaration the runway declaration to aid checking thresholds
   * @param obstacleDeclaration the obstacle declaration to check
   * @throws FormatException specifies which parameter is incorrect
   */
  public static void sanitiseObstacle(RunwayDeclaration runwayDeclaration, ObstacleDeclaration obstacleDeclaration, int blastProtection) throws FormatException {
        if (OBSTACLE_MAX_HEIGHT < obstacleDeclaration.getHeight()) throw new HeightException();
        if (obstacleDeclaration.getHeight() <= 0) throw new HeightException();
        if (75 < Math.abs(obstacleDeclaration.getThresholdCentre())) throw new CentreException();
        if (obstacleDeclaration.getThresholdToward() < -60 || obstacleDeclaration.getThresholdAway() < -60) throw new ThresholdException();
        if (runwayDeclaration.getLDA() < obstacleDeclaration.getThresholdToward()
            || runwayDeclaration.getLDA() < obstacleDeclaration.getThresholdAway())
          throw new ThresholdException();
        if (runwayDeclaration.getLDA() < blastProtection) throw new BPException();
        if (blastProtection < 0) throw new BPException();
        if (obstacleDeclaration.getHeading() > 36 || obstacleDeclaration.getHeading() < 0) throw new HeadingException();
    if (obstacleDeclaration.getHeading() != runwayDeclaration.getHeading()
        && obstacleDeclaration.getHeading() != limit((runwayDeclaration.getHeading() + 18) % 36))
      throw new HeadingException();
  }

  /**
   * Helper method to format headings appropriately
   * @param num heading
   * @return formatted heading
   */
  private static int limit(int num) {
    if (num == 0) return 36;
    return num;
  }
}
