package utils;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

/**
 * Holds the values that define a runway
 */
public class RunwayDeclaration {

  /**
   * LDA
   */
  private final SimpleIntegerProperty LDA;

  /**
   * TORA
   */
  private final SimpleIntegerProperty TORA;

  /**
   * ASDA
   */
  private final SimpleIntegerProperty ASDA;

  /**
   * TODA
   */
  private final SimpleIntegerProperty TODA;

  /**
   * Heading
   */
  private final SimpleIntegerProperty heading;

  /**
   * Designator for heading
   */
  private final SimpleStringProperty headingExtension;


  /**
   * Constructor to initialise runway values to -1
   */
  public RunwayDeclaration() {
    this.LDA = new SimpleIntegerProperty(-1);
    this.TORA = new SimpleIntegerProperty(-1);
    this.ASDA = new SimpleIntegerProperty(-1);
    this.TODA = new SimpleIntegerProperty(-1);
    this.heading = new SimpleIntegerProperty(-1);
    this.headingExtension = new SimpleStringProperty("");
  }

  /**
   * Constructor to initialise runway values to supplied values
   * @param LDA the LDA value
   * @param TORA the TORA value
   * @param ASDA the ASDA value
   * @param TORA the TORA value
   * @param heading the heading of the runway
   * @param headingExtension the indicator of the runway heading
   */
  public RunwayDeclaration(int LDA, int TORA, int ASDA, int TODA, int heading, String headingExtension) {
    this.LDA = new SimpleIntegerProperty(LDA);
    this.TORA = new SimpleIntegerProperty(TORA);
    this.ASDA = new SimpleIntegerProperty(ASDA);
    this.TODA = new SimpleIntegerProperty(TODA);
    this.heading = new SimpleIntegerProperty(heading);
    this.headingExtension = new SimpleStringProperty(headingExtension);
  }

  /**
   * Constructor to initialise runway values from a declaration
   * @param declaration the runway declaration
   */
  public RunwayDeclaration(RunwayDeclaration declaration) {
    this.LDA = new SimpleIntegerProperty(declaration.getLDA());
    this.TORA = new SimpleIntegerProperty(declaration.getTORA());
    this.ASDA = new SimpleIntegerProperty(declaration.getASDA());
    this.TODA = new SimpleIntegerProperty(declaration.getTODA());
    this.heading = new SimpleIntegerProperty(declaration.getHeading());
    this.headingExtension = new SimpleStringProperty(declaration.getHeadingExtension());
  }

  /**
   * Getter method for LDA value
   * @return LDA
   */
  public int getLDA() {
    return LDA.get();
  }

  /**
   * Getter method for LDA property
   * @return simpleintegerproperty for LDA
   */
  public SimpleIntegerProperty getLDAProperty() {
    return LDA;
  }

  /**
   * Setter method for LDA value
   * @param LDA the LDA value
   */
  public void setLDA(int LDA) {
    this.LDA.set(LDA);
  }

  /**
   * Getter method for TORA value
   * @return TORA
   */
  public int getTORA() {
    return TORA.get();
  }

  /**
   * Getter method for TORA property
   * @return simpleintegerproperty for TORA
   */
  public SimpleIntegerProperty getTORAProperty() {
    return TORA;
  }

  /**
   * Setter method for TORA value
   * @param TORA the TORA value
   */
  public void setTORA(int TORA) {
    this.TORA.set(TORA);
  }

  /**
   * Getter method for ASDA value
   * @return ASDA
   */
  public int getASDA() {
    return ASDA.get();
  }

  /**
   * Getter method for ASDA property
   * @return simpleintegerproperty for ASDA
   */
  public SimpleIntegerProperty getASDAProperty() {
    return ASDA;
  }

  /**
   * Setter method for ASDA value
   * @param ASDA the ASDA value
   */
  public void setASDA(int ASDA) {
    this.ASDA.set(ASDA);
  }

  /**
   * Getter method for TODA value
   * @return TODA
   */
  public int getTODA() {
    return TODA.get();
  }

  /**
   * Getter method for TODA property
   * @return simpleintegerproperty
   */
  public SimpleIntegerProperty getTODAProperty() {
    return TODA;
  }

  /**
   * Setter method for TODA value
   * @param TODA the TODA value
   */
  public void setTODA(int TODA) {
    this.TODA.set(TODA);
  }

  /**
   * Getter method for heading value
   * @return heading
   */
  public int getHeading() {
    return heading.get();
  }

  /**
   * Getter method for heading property
   * @return heading simpleIntegerProperty
   */
  public SimpleIntegerProperty headingProperty() {
    return heading;
  }

  /**
   * Setter method for heading value
   * @param heading the heading value
   */
  public void setHeading(int heading) {
    this.heading.set(heading);
  }

  /**
   * Getter method for heading indicator value
   * @return heading designator
   */
  public String getHeadingExtension() {
    return headingExtension.get();
  }

  /**
   * Getter method for heading indicator property
   * @return simplestringproperty for heading
   */
  public SimpleStringProperty headingExtensionProperty() {
    return headingExtension;
  }

  /**
   * Setter method for heading indicator value
   * @param headingExtension the heading indicator
   */
  public void setHeadingExtension(String headingExtension) {
    this.headingExtension.set(headingExtension);
  }

  /**
   * Setter method for runway values from a declaration
   * @param declaration the runway declaration
   */
  public void setVars(RunwayDeclaration declaration) {
    this.setLDA(declaration.getLDA());
    this.setTORA(declaration.getTORA());
    this.setASDA(declaration.getASDA());
    this.setTODA(declaration.getTODA());
    this.setHeading(declaration.getHeading());
    this.setHeadingExtension(declaration.getHeadingExtension());
  }

  /**
   * Getter method for distance values
   * @return integer values with declaration
   */
  public int[] getDistanceVals() {
    return new int[]{getASDA(),getLDA(),getTODA(),getTORA()};
  }
}
