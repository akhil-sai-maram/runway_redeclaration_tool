package exceptions;

public class HeightException extends FormatException{
}
