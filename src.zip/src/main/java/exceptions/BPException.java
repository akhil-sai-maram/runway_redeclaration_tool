package exceptions;

public class BPException extends FormatException{
}
