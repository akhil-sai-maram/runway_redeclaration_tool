package exceptions;

public class TORAException extends FormatException{
}
