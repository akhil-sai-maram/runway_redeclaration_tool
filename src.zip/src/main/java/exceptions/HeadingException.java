package exceptions;

public class HeadingException extends FormatException{

}
