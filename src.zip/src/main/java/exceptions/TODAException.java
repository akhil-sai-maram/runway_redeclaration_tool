package exceptions;

public class TODAException extends FormatException{
}
