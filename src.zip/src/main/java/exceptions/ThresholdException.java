package exceptions;

public class ThresholdException extends FormatException{
}
