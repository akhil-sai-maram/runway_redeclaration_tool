package exceptions;

public class ASDAException extends FormatException{
}
