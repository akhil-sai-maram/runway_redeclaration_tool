package exceptions;

public class CentreException extends FormatException{
}
