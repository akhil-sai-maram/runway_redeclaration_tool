package exceptions;

public class FormatException extends Exception {
}
