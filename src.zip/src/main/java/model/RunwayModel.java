package model;

import java.util.HashMap;
import utils.ObstacleDeclaration;
import utils.RunwayDeclaration;
import utils.RunwayUtils;

/**
 * Handle calculations for runway declaration based on the type of declaration
 */
public class RunwayModel {

  /**
   * The types of declaration
   */
  public enum DeclarationType {
    LANDING_TOWARD,
    LANDING_OVER,
    TAKEOFF_OVER,
    TAKEOFF_AWAY
  }

  /**
   * Used to hold the declarations of all the tabs
   */
  private final HashMap<Integer, RunwayDeclaration> declarations = new HashMap<>();

  /**
   * The runway declaration for the current tab
   */
  private final RunwayDeclaration runwayDeclaration = new RunwayDeclaration();

  /**
   * Performs the correct type of redeclaration
   * @param obstacleDeclaration the obstacle declaration
   * @param declarationType the type of declaration we are performing
   * @param blastProtection safety area	behind aircraft: prevents	engine blast from	affecting	any
   * obstacles located behind it
   * @return updated runwayDeclaration
   */
  public RunwayDeclaration redeclare(ObstacleDeclaration obstacleDeclaration, DeclarationType declarationType, int blastProtection) {
    RunwayDeclaration declaration = new RunwayDeclaration(this.runwayDeclaration);
    switch (declarationType) {
      case LANDING_TOWARD -> RunwayUtils.landingToward(declaration, obstacleDeclaration);
      case LANDING_OVER -> RunwayUtils.landingOver(declaration, obstacleDeclaration);
      case TAKEOFF_OVER -> RunwayUtils.takeoffOver(declaration, obstacleDeclaration);
      case TAKEOFF_AWAY -> RunwayUtils.takeoffAway(declaration, obstacleDeclaration, blastProtection);
    }
    return declaration;
  }

  /**
   * Add a new runway declaration for a new tab
   * @param index of the new declaration
   * @param declaration the new declaration to be added
   */
  public void addRunwayDeclaration(int index, RunwayDeclaration declaration) {
    declarations.put(index, declaration);
  }

  /**
   * Change the current declaration when switching tabs
   * @param index of the declaration we are now using
   */
  public void setRunwayDeclaration(int index) {
    runwayDeclaration.setVars(declarations.get(index));
  }

  /**
   * Get the declaration we are currently working on
   * @return currently working declaration
   */
  public RunwayDeclaration getRunwayDeclaration(){
    return new RunwayDeclaration(runwayDeclaration);
  }
}
