package control;

import exceptions.CentreException;
import exceptions.FormatException;
import exceptions.HeadingException;
import exceptions.HeightException;
import exceptions.ThresholdException;
import java.util.HashMap;
import javafx.application.Application;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import listeners.DeclarationListener;
import listeners.ErrorListener;
import model.RunwayModel;
import model.RunwayModel.DeclarationType;
import utils.ObstacleDeclaration;
import utils.RunwayDeclaration;
import utils.Sanitisation;
import view.ToolWindow;


/**
 * JavaFX Application class
 */
public class App extends Application implements DeclarationListener, ErrorListener {
  
  private static App instance;

  /**
   * The model that holds the declaration currently being worked on
   */
  private final RunwayModel model = new RunwayModel();

  /**
   * HashMap used for tab functionality
   */
  private final HashMap<Integer, RunwayDeclaration> declarations = new HashMap<>();

  /**
   * To store the modified declaration after a redeclare
   */
  private final RunwayDeclaration runwayDeclaration = new RunwayDeclaration();

  public Stage stage;
  private ToolWindow window;

  /**
   * Start the tool
   * @param args commandline arguments
   */
  public static void main(String[] args) {
    //logger.info("Starting client");
    launch(args);
  }

  /**
   * Begins the program by opening the ToolWindow
   * @param primaryStage default stage, main window
   */
  @Override
  public void start(Stage primaryStage) {
    instance = this;

    //Initialise runway declaration and assign it to model
    RunwayDeclaration runwayDeclaration = new RunwayDeclaration(3884, 3884, 3884, 3962, 27, "R");
    declarations.put(0, runwayDeclaration);
    this.runwayDeclaration.setVars(runwayDeclaration);
    model.addRunwayDeclaration(0, runwayDeclaration);
    model.setRunwayDeclaration(0);
    this.stage = primaryStage;

    //Open toolWindow
    openTool();

    //Add listeners
    window.addListener(this);
  }

  /**
   * Get a single App instance
   * @return app
   */
  public static App getInstance() {
    return instance;
  }

  /**
   * Create ToolWindow with specified dimensions
   */
  public void openTool() {
    window = new ToolWindow(stage,800,675);
    stage.setScene(window.getScene());
    stage.show();
  }

  public RunwayDeclaration getRunwayDeclaration() {
    return runwayDeclaration;
  }

  public void setRunwayDeclaration(int index) {
    runwayDeclaration.setVars(declarations.get(index));
    model.setRunwayDeclaration(index);
  }

  /**
   * Shutdown program
   */
  public void shutdown() {
    //logger.info("Shutting down");
    System.exit(0);
  }

  /**
   * Adds a new runway declaration for use in a new tab
   * @param declaration the declaration of the new runway
   */
  @Override
  public void declare(RunwayDeclaration declaration) {
    //Assign declaration to model
    model.addRunwayDeclaration(window.getCurrentID(), declaration);
    declarations.put(window.getCurrentID(), declaration);
  }

  /**
   * Redeclare the currently selected runway
   * @param declaration the declaration of the obstacle
   * @param declarationType mode that user selects
   * @param blastProtection the blast protection
   * @throws Exception when a redeclare is given an invalid declaration or
   * would produce an invalid declaration
   */
  @Override
  public void redeclare(ObstacleDeclaration declaration, DeclarationType declarationType,
      int blastProtection) throws Exception {
    try {
      int selectedTab = window.getSelectedTab();
      model.setRunwayDeclaration(selectedTab);
      runwayDeclaration.setVars(model.getRunwayDeclaration());

      //Check the obstacle declaration falls within acceptable values
      Sanitisation.sanitiseObstacle(runwayDeclaration, declaration, blastProtection);
      RunwayDeclaration dec = model.redeclare(declaration, declarationType, blastProtection);

      //Check the resulting declaration doesn't violate any of the runway regulations
      Sanitisation.sanitiseRedeclaration(dec);

      runwayDeclaration.setVars(dec);
      declarations.replace(selectedTab, dec);
    } catch (FormatException e) {
      if (e instanceof CentreException) {
        errorCentre();
      } else if (e instanceof HeightException) {
        errorHeight();
      } else if (e instanceof ThresholdException) {
        errorThreshold();
      } else if (e instanceof HeadingException) {
        errorHeading();
      } else {
        //Exit condition
         Alert alert = new Alert(AlertType.ERROR, "The calculated thresholds are not within expected values.");
         alert.setTitle("An Unexpected Error Occurred");
         alert.showAndWait();
      }
      throw new Exception();
    }
  }

  /**
   * Error for invalid LDA
   */
  @Override
  public void errorLDA() {
    window.errorLDA();
  }

  /**
   * Error for invalid TORA
   */
  @Override
  public void errorTORA() {
    window.errorTORA();
  }

  /**
   * Error for invalid ASDA
   */
  @Override
  public void errorASDA() {
    window.errorASDA();
  }

  /**
   * Error for invalid TODA
   */
  @Override
  public void errorTODA() {
    window.errorTODA();
  }

  /**
   * Error for invalid threshold
   */
  @Override
  public void errorThreshold() {
    window.errorThreshold();
  }

  /**
   * Error for invalid centre
   */
  @Override
  public void errorCentre() {
    window.errorCentre();
  }

  /**
   * Error for invalid height
   */
  @Override
  public void errorHeight() {
    window.errorHeight();
  }

  /**
   * Error for invalid blast protection
   */
  @Override
  public void errorBP() {
    window.errorBP();
  }

  /**
   * Error for incorrect heading
   */
  @Override
  public void errorHeading() {
    window.errorHeading();
  }

}
